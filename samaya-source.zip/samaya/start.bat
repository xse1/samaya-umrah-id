@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (echo Run setup.bat first. & pause & exit /b 1)
start "Samaya API - close to stop" cmd /k ".venv\Scripts\python.exe -m uvicorn main:app --app-dir backend --host 127.0.0.1 --port 8000"
start "Samaya UI - close to stop" cmd /k "npm --prefix frontend run dev"
.venv\Scripts\python scripts\wait_for_server.py
if errorlevel 1 (pause & exit /b 1)
start http://localhost:5173
