import json
import os
import shutil
import subprocess
import tempfile
from pathlib import Path
import cv2
import numpy as np
import pytesseract
from PIL import Image
from names import select_name


def _recognize_name(image,native=False,focused=False):
    root=Path(__file__).resolve().parents[1]
    width,height=image.size
    # Whole-page sparse text covers layouts beyond the optional Arabic-side crop.
    regions=[([0,0,1,1],7),([0,0,1,1],6)] if focused else [([0,0,1,.74],11),([.45,.10,.54,.55],6)]
    lines=[]
    with tempfile.TemporaryDirectory(prefix='samaya-arabic-') as folder:
        inputs=[]
        for index,(region,psm) in enumerate(regions):
            x,y,w,h=region
            crop=image.crop((int(x*width),int(y*height),int((x+w)*width),int((y+h)*height))).convert('RGB')
            scale=max(1,min(3,2200/width));crop=crop.resize((round(crop.width*scale),round(crop.height*scale)),Image.Resampling.LANCZOS)
            gray=cv2.cvtColor(np.array(crop),cv2.COLOR_RGB2GRAY)
            if index:gray=cv2.bilateralFilter(gray,5,30,30)
            filename=Path(folder)/f'arabic-{index}.png';Image.fromarray(gray).save(filename)
            inputs.append({'file':str(filename),'region':region,'psm':psm,'width':crop.width,'height':crop.height})
            if native:
                model=root/'backend/tessdata_arabic'
                model_config=f' --tessdata-dir \"{model}\"' if (model/'ara.traineddata').exists() else ''
                data=pytesseract.image_to_data(gray,lang='ara',config=f'--psm {psm} --dpi 300'+model_config,output_type=pytesseract.Output.DICT)
                grouped={}
                for i,text in enumerate(data['text']):
                    if not text.strip():continue
                    key=(data['block_num'][i],data['par_num'][i],data['line_num'][i]);grouped.setdefault(key,[]).append(i)
                for indices in grouped.values():
                    ar=[i for i in indices if any('\u0621'<=c<='\u064A' for c in data['text'][i])]
                    if not ar:continue
                    left=min(data['left'][i] for i in indices);top=min(data['top'][i] for i in indices)
                    right=max(data['left'][i]+data['width'][i] for i in indices);bottom=max(data['top'][i]+data['height'][i] for i in indices)
                    lines.append({'text':' '.join(data['text'][i] for i in indices),'confidence':sum(float(data['conf'][i]) for i in ar)/len(ar),'box':[x+left/crop.width*w,y+top/crop.height*h,x+right/crop.width*w,y+bottom/crop.height*h]})
        if not native:
            manifest=Path(folder)/'inputs.json';manifest.write_text(json.dumps(inputs),encoding='utf-8')
            node=os.getenv('SAMAYA_NODE') or shutil.which('node')
            if not node:return select_name([])
            result=subprocess.run([node,str(root/'scripts/arabic_name_worker.cjs'),str(manifest)],capture_output=True,text=True,encoding='utf-8',timeout=120,cwd=root)
            if result.returncode:return select_name([])
            lines=json.loads(result.stdout)
    return select_name(lines,focused=focused)


def recognize_name(image,native=False,focused=False):
    try:return _recognize_name(image,native=native,focused=focused)
    except Exception:
        return {'name':'','name_confidence':0,'name_status':'تعذرت قراءة الاسم العربي؛ أعد تحديد موضعه أو أدخله يدويًا من الجواز'}
