import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import pytest
import main
from fastapi.testclient import TestClient

@pytest.fixture
def client(tmp_path,monkeypatch):
    monkeypatch.setattr(main,'DB',tmp_path/'test.db')
    main.JOBS.clear();main.init_db()
    with TestClient(main.app) as c:
        c.headers['X-Samaya-Token']=c.get('/api/session').json()['token']
        yield c
