from names import select_name,clean_candidate

def line(text,confidence=90,box=None):return {'text':text,'confidence':confidence,'box':box or [.5,.2,.95,.25]}

def test_rejects_garbled_longest_line():
    result=select_name([line('و دن ال الماك للخ الس اام',98),line('عبد الله أحمد محمد',89)])
    assert result['name']=='عبد الله أحمد محمد'

def test_rejects_low_confidence_and_field_values():
    assert select_name([line('محمد أحمد محمود علي',32)])['name']==''
    assert select_name([line('الجمهورية اليمنية',99),line('مكان الميلاد حضرموت',98),line('طالب يمني متزوج',96)])['name']==''

def test_name_label_and_arabic_only():
    result=select_name([line('الاسم الكامل: محمد أحمد محمود علي',76)])
    assert result['name']=='محمد أحمد محمود علي'
    assert not clean_candidate('P<YEMAHMED<<MOHAMMED')
    assert not clean_candidate('الاسم محمد احمد PASSPORT 123456')

def test_conflicting_readings_are_not_guessed():
    result=select_name([line('محمد أحمد محمود علي',90),line('محمود أحمد محمد علي',89)])
    assert result['name']=='' and 'متعارضة' in result['name_status']

def test_two_word_name_needs_field_anchor():
    assert select_name([line('محمد أحمد',90)])['name']==''
    assert select_name([line('الاسم',90, [.7,.16,.95,.19]),line('محمد أحمد',75)])['name']=='محمد أحمد'

def test_spelling_variants_are_not_unrelated_names():
    result=select_name([line('الاسمالكامل',90,[.7,.16,.95,.19]),line('محمد أحمد محمود علي',90),line('محمد احمد محمودعلى',91)])
    assert result['name']


def test_arabic_ocr_on_local_rendered_fixture(tmp_path):
    import pytest
    from ocr import wasm_ready
    if not wasm_ready():pytest.skip('Local Node OCR engine and Arabic models required')
    from pathlib import Path
    import fitz
    from PIL import Image
    from name_ocr import recognize_name
    from names import name_key
    fonts=Path(__file__).resolve().parents[1]/'fonts'
    doc=fitz.open();page=doc.new_page(width=720,height=450)
    css="@font-face{font-family:Cairo;src:url(Cairo.ttf)}body{font-family:Cairo;direction:rtl;font-size:22pt}"
    for rect,text,size in [((365,90,700,140),'الاسم الكامل',17),((300,140,700,210),'محمد أحمد محمود علي',26),((350,240,700,300),'مكان الميلاد',17),((350,295,700,360),'الجنسية',17)]:
        page.insert_htmlbox(fitz.Rect(rect),'<div style="text-align:right;font-size:'+str(size)+'pt">'+text+'</div>',css=css,archive=fitz.Archive(str(fonts)))
    path=tmp_path/'arabic-name.png';page.get_pixmap(matrix=fitz.Matrix(2,2)).save(path);doc.close()
    result=recognize_name(Image.open(path))
    assert name_key(result['name'])==name_key('محمد أحمد محمود علي')
    assert result['name_confidence']>=70
