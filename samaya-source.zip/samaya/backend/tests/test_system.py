import io
import os
import json
import sqlite3
import time
from pathlib import Path
import pytest
from PIL import Image
from pypdf import PdfReader
import main
from ocr import parse_text,arabic_name,portrait,check_digit

def png():
    s=io.BytesIO();Image.new('RGB',(500,650),'white').save(s,'PNG');return s.getvalue()

def media(client):return client.post('/api/images',files={'file':('image.png',png(),'image/png')}).json()['id']

def record(client,number='A1234567'):
    key=media(client)
    return {'name':'عبد الله أحمد محمد','passport':number,'photo':key,'hotel':'فندق الرحاب','supervisor':'أحمد محمد','phone':'0501234567','qr':key,'reviewed':True,'approved':True}

def test_mrz():
    line='L898902C36UTO7408122F1204159ZE184226B<<<<<10'
    assert len(line)==44
    assert parse_text(line)=={'passport':'L898902C3','mrz_valid':True}
    assert not parse_text(line[:9]+'0'+line[10:])['mrz_valid']
    assert parse_text('Passport A12345678')['passport']=='A12345678'
    assert not parse_text('لا يوجد رقم')['passport']

def test_arabic_name_not_from_mrz():
    assert arabic_name('P<YEMALHADDAD<<AHMED\nالجمهورية اليمنية\nعبد الله أحمد محمد')=='عبد الله أحمد محمد'
    assert arabic_name('P<YEMALHADDAD<<AHMED')==''

def test_portrait_and_manual_crop(client):
    assert portrait(Image.new('RGB',(500,500),'white')) is None
    key=media(client)
    r=client.post('/api/crop',json={'image':key,'x':.1,'y':.1,'width':.5,'height':.4})
    assert r.status_code==200
    image=Image.open(io.BytesIO(client.get('/api/media/'+r.json()['id']).content))
    assert image.size==(250,260)
    assert client.post('/api/crop',json={'image':key,'x':.8,'y':0,'width':.5,'height':1}).status_code==422

def test_crud_duplicate_and_persistence(client):
    d=record(client);r=client.post('/api/pilgrims',json=d);assert r.status_code==200
    saved=r.json();assert saved['approved']
    assert client.post('/api/pilgrims',json=d).status_code==409
    saved['name']='محمد أحمد عبد الله';assert client.post('/api/pilgrims',json=saved).status_code==200
    main.init_db()
    with sqlite3.connect(main.DB) as db:assert json.loads(db.execute('SELECT data FROM pilgrims').fetchone()[0])['name']==saved['name']
    assert client.get('/api/pilgrims').json()[0]['id']==saved['id']
    assert client.delete('/api/pilgrims/'+saved['id']).status_code==200
    assert client.get('/api/pilgrims').json()==[]

def test_review_and_required(client):
    d=record(client);d['reviewed']=False
    assert client.post('/api/pilgrims',json=d).status_code==422
    d['reviewed']=True;d['photo']=None
    assert client.post('/api/pilgrims',json=d).status_code==422
    assert client.post('/api/pilgrims',json={'name':'مسودة'}).status_code==200
    assert client.post('/api/pdf',json={'ids':[client.get('/api/pilgrims').json()[0]['id']]}).status_code==422

def test_upload_security(client):
    assert client.post('/api/images',files={'file':('bad.jpg',b'MZ executable','image/jpeg')}).status_code==400
    assert client.post('/api/images',files={'file':('bad.svg',b'<svg><script>alert(1)</script></svg>','image/svg+xml')},data={'kind':'logo'}).status_code==400
    assert client.get('/api/settings',headers={'origin':'https://evil.example'}).status_code==403
    assert client.post('/api/pilgrims',json={},headers={'X-Samaya-Token':'wrong'}).status_code==403

def test_backup_restore_atomic_and_encrypted(client):
    saved=client.post('/api/pilgrims',json=record(client)).json()
    backup=client.post('/api/backup',json={'password':'secret'}).content
    assert b'A1234567' not in backup
    client.delete('/api/pilgrims/'+saved['id'])
    bad=client.post('/api/restore',files={'file':('x.backup',backup)},data={'password':'bad','confirmation':'استعادة'})
    assert bad.status_code==400 and client.get('/api/pilgrims').json()==[]
    good=client.post('/api/restore',files={'file':('x.backup',backup)},data={'password':'secret','confirmation':'استعادة'})
    assert good.status_code==200
    assert client.get('/api/pilgrims').json()[0]['passport']=='A1234567'
    invalid=json.dumps({'version':1,'records':[saved,saved],'settings':main.get_settings(),'media':[]}).encode()
    assert client.post('/api/restore',files={'file':('x',invalid)},data={'confirmation':'استعادة'}).status_code==400
    assert len(client.get('/api/pilgrims').json())==1

def test_queue_multiple_real_failure_fallback(client,monkeypatch):
    def unavailable(image):raise RuntimeError('OCR not installed')
    monkeypatch.setattr(main,'extract',unavailable)
    response=client.post('/api/passports',files=[('files',('one.png',png(),'image/png')),('files',('two.png',png(),'image/png'))])
    assert response.status_code==200
    for _ in range(100):
        if len(client.get('/api/pilgrims').json())==2:break
        time.sleep(.03)
    jobs=client.get('/api/jobs').json()
    assert len(jobs)==2 and all(j['progress']==100 for j in jobs)
    assert all(not r['approved'] and r['source'] for r in client.get('/api/pilgrims').json())

@pytest.mark.skipif(os.getenv("SAMAYA_TEST_NATIVE_PDF")!="1",reason="Optional server Chromium engine; primary UI PDF is rendered in the browser. Set SAMAYA_TEST_NATIVE_PDF=1 to test native export.")
def test_pdf_exact_size_shared_template(client):
    d=client.post('/api/pilgrims',json=record(client)).json()
    html=client.post('/api/preview',json={'records':[d]}).text
    assert '85.60mm' in html and d['name'] in html
    r=client.post('/api/pdf',json={'ids':[d['id']],'mode':'cr80'})
    assert r.status_code==200,r.text if r.status_code!=200 else ''
    reader=PdfReader(io.BytesIO(r.content));assert len(reader.pages)==1
    page=reader.pages[0]
    assert abs(float(page.mediabox.width)*25.4/72-85.60)<.1
    assert abs(float(page.mediabox.height)*25.4/72-53.98)<.1
    a4=client.post('/api/pdf',json={'ids':[d['id']],'mode':'a4'})
    page=PdfReader(io.BytesIO(a4.content)).pages[0]
    assert abs(float(page.mediabox.width)*25.4/72-210)<.1
    assert abs(float(page.mediabox.height)*25.4/72-297)<.1

def test_source_and_campaign_delete(client):
    d=record(client);d['source']=d['photo'];saved=client.post('/api/pilgrims',json=d).json()
    assert client.delete('/api/pilgrims/'+saved['id']+'/source').status_code==200
    assert client.get('/api/media/'+saved['photo']).status_code==200
    assert not client.get('/api/pilgrims').json()[0]['source']
    assert client.post('/api/campaign/delete',json={'campaign':'الحملة الرئيسية','confirmation':'wrong'}).status_code==422
    assert client.post('/api/campaign/delete',json={'campaign':'الحملة الرئيسية','confirmation':'الحملة الرئيسية'}).status_code==200
    assert client.get('/api/pilgrims').json()==[]


def test_physical_pdf_page_boxes():
    import fitz
    from pdf_utils import exact_page_boxes
    doc=fitz.open();doc.new_page(width=300,height=200);doc.new_page(width=300,height=200)
    raw=doc.tobytes();doc.close()
    for a4,width,height in [(False,85.6,53.98),(True,210,297)]:
        reader=PdfReader(io.BytesIO(exact_page_boxes(raw,a4)))
        assert len(reader.pages)==2
        for page in reader.pages:
            assert abs(float(page.mediabox.width)*25.4/72-width)<.000001
            assert abs(float(page.mediabox.height)*25.4/72-height)<.000001
            assert list(page.cropbox)==list(page.mediabox)

def test_browser_print_layout_requires_saved_approval(client,monkeypatch):
    def no_native(html):raise RuntimeError('native engine unavailable')
    monkeypatch.setattr(main,'create_pdf',no_native)
    approved=client.post('/api/pilgrims',json=record(client)).json()
    r=client.post('/api/print-layout',json={'ids':[approved['id']],'mode':'cr80'})
    assert r.status_code==200 and approved['name'] in r.text
    draft=client.post('/api/pilgrims',json={'name':'مسودة غير معتمدة'}).json()
    assert client.post('/api/print-layout',json={'ids':[draft['id']]}).status_code==422
    assert client.post('/api/print-layout',json={'records':[approved]}).status_code==422
    assert client.post('/api/print-layout',json={'mode':'a4','test':True}).status_code==200
