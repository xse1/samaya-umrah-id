import base64
import csv
import io
import json
import os
import re
import secrets
import sqlite3
import threading
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Optional

import cv2
import fitz
import numpy as np
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import HTMLResponse, Response, JSONResponse
from PIL import Image, ImageOps, UnidentifiedImageError
from pydantic import BaseModel, Field
from starlette.concurrency import run_in_threadpool

from card import render
from ocr import extract,portrait,wasm_ready

from dotenv import load_dotenv
ROOT=Path(__file__).resolve().parent
load_dotenv(ROOT.parent/'.env')
import pytesseract
import shutil
_tesseract=os.getenv('TESSERACT_CMD') or shutil.which('tesseract')
if not _tesseract and os.name=='nt':
    _tesseract=r'C:\Program Files\Tesseract-OCR\tesseract.exe'
if _tesseract:pytesseract.pytesseract.tesseract_cmd=_tesseract
if (ROOT/'tessdata/ara.traineddata').exists():os.environ['TESSDATA_PREFIX']=str(ROOT/'tessdata')
DATA=Path(os.getenv('SAMAYA_DATA',str(ROOT/'data')))
DATA.mkdir(parents=True,exist_ok=True)
DB=DATA/'samaya.db'
LOCK=threading.RLock()
POOL=ThreadPoolExecutor(max_workers=1)
JOBS={}
TOKEN=secrets.token_urlsafe(32)
MAX_BYTES=20*1024*1024
Image.MAX_IMAGE_PIXELS=30_000_000

def connection():
    c=sqlite3.connect(DB,timeout=30)
    c.row_factory=sqlite3.Row
    return c

def init_db():
    with connection() as c:
        c.executescript('''CREATE TABLE IF NOT EXISTS pilgrims(id TEXT PRIMARY KEY, passport TEXT UNIQUE, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS media(id TEXT PRIMARY KEY,data BLOB NOT NULL);
        CREATE TABLE IF NOT EXISTS settings(id INTEGER PRIMARY KEY CHECK(id=1),data TEXT NOT NULL);''')
        c.execute('INSERT OR IGNORE INTO settings VALUES(1,?)',(json.dumps({'primary':'#329DD0','accent':'#F68B50','secondary':'#666666','logo_width':28,'campaign':'الحملة الرئيسية'}),))
init_db()

app=FastAPI(title='نظام سمايا المحلي',docs_url=None,redoc_url=None)
app.add_middleware(TrustedHostMiddleware,allowed_hosts=['127.0.0.1','localhost','testserver'])
app.add_middleware(CORSMiddleware,allow_origins=['http://localhost:5173','http://127.0.0.1:5173'],allow_methods=['*'],allow_headers=['Content-Type','X-Samaya-Token'])

@app.middleware('http')
async def local_security(request:Request,call_next):
    origin=request.headers.get('origin')
    if origin and origin not in ['http://localhost:5173','http://127.0.0.1:5173','http://127.0.0.1:8000','http://localhost:8000']:
        return Response('مصدر الطلب غير مسموح',403)
    if int(request.headers.get('content-length','0'))>650*1024*1024:
        return Response('الدفعة أكبر من الحد المسموح',413)
    if request.method not in ['GET','HEAD','OPTIONS'] and request.headers.get('x-samaya-token')!=TOKEN:
        return Response('أعد تحميل الواجهة لتجديد جلسة الاتصال المحلي',403)
    response=await call_next(request)
    response.headers['Cache-Control']='no-store'
    response.headers['X-Content-Type-Options']='nosniff'
    response.headers['Referrer-Policy']='no-referrer'
    return response

@app.exception_handler(Exception)
async def unexpected_error(request:Request,exc:Exception):
    return JSONResponse({'detail':'تعذر إتمام العملية. افحص نافذة الخادم وإعدادات التشغيل المحلي ثم أعد المحاولة.'},status_code=500)

@app.get('/api/session')
def session(): return {'token':TOKEN}

@app.get('/api/health')
def health():
    import pytesseract
    try: languages=pytesseract.get_languages(config='');ocr={'ready':{'ara','eng'}.issubset(languages),'languages':languages}
    except Exception: ocr={'ready':False,'languages':[]}
    if not ocr['ready'] and wasm_ready():ocr={'ready':True,'languages':['ara','eng'],'engine':'Tesseract.js محلي'}
    return {'ok':True,'ocr':ocr,'font':(ROOT/'fonts/Cairo.ttf').exists()}

def get_settings():
    with connection() as c: return json.loads(c.execute('SELECT data FROM settings WHERE id=1').fetchone()[0])

@app.get('/api/settings')
def settings(): return get_settings()

class Settings(BaseModel):
    primary:str='#329DD0'
    accent:str='#F68B50'
    secondary:str='#666666'
    logo_width:float=Field(28,ge=10,le=42)
    logo:Optional[str]=None
    qr:Optional[str]=None
    hotel:str=Field('',max_length=70)
    supervisor:str=Field('',max_length=70)
    phone:str=Field('',max_length=25)
    campaign:str=Field('الحملة الرئيسية',min_length=1,max_length=80)

@app.put('/api/settings')
def save_settings(s:Settings):
    for col in (s.primary,s.accent,s.secondary):
        if not re.fullmatch('#[0-9a-fA-F]{6}',col): raise HTTPException(422,'صيغة اللون غير صحيحة')
    for key in [s.logo,s.qr]:
        if key: media_bytes(key)
    with connection() as c: c.execute('UPDATE settings SET data=? WHERE id=1',(s.model_dump_json(),))
    return s

def save_image(image):
    image=ImageOps.exif_transpose(image)
    if image.mode in ['RGBA','LA'] or 'transparency' in image.info:
        rgba=image.convert('RGBA');background=Image.new('RGBA',rgba.size,'white');image=Image.alpha_composite(background,rgba)
    image=image.convert('RGB')
    if image.width*image.height>30_000_000: raise HTTPException(400,'الصورة كبيرة جدًا')
    image.thumbnail((3000,3000))
    stream=io.BytesIO();image.save(stream,'PNG');key=uuid.uuid4().hex
    with connection() as c:c.execute('INSERT INTO media VALUES(?,?)',(key,stream.getvalue()))
    return key

def media_bytes(key):
    if key=='original':
        p=ROOT.parent/'frontend/public/assets/samaya-logo.jpg'
        if not p.exists():p=p.with_suffix('.png')
        if p.exists():
            s=io.BytesIO();Image.open(p).convert('RGB').save(s,'PNG');return s.getvalue()
    with connection() as c: r=c.execute('SELECT data FROM media WHERE id=?',(key,)).fetchone()
    if not r: raise HTTPException(404,'الصورة غير موجودة')
    return r[0]

@app.get('/api/media/{key}')
def get_media(key:str): return Response(media_bytes(key),media_type='image/png')

async def uploaded_bytes(file):
    b=await file.read(MAX_BYTES+1)
    if len(b)>MAX_BYTES: raise HTTPException(413,'الحد الأقصى للملف 20 ميجابايت')
    return b

def open_image(b):
    try:
        image=Image.open(io.BytesIO(b))
        if image.format not in ['JPEG','PNG','WEBP']:raise ValueError()
        if image.width*image.height>30_000_000:raise ValueError()
        image.load();image=ImageOps.exif_transpose(image)
        if image.mode in ['RGBA','LA'] or 'transparency' in image.info:
            rgba=image.convert('RGBA');image=Image.alpha_composite(Image.new('RGBA',rgba.size,'white'),rgba)
        return image.convert('RGB')
    except (UnidentifiedImageError,ValueError,OSError,Image.DecompressionBombError): raise HTTPException(400,'ارفع صورة JPG أو PNG أو WEBP سليمة وبحجم مناسب')

@app.post('/api/images')
async def image_upload(file:UploadFile=File(...),kind:str=Form('photo')):
    b=await uploaded_bytes(file)
    # SVG is rasterized in an isolated browser with network blocked; never served as active markup.
    if (file.filename or '').lower().endswith('.svg'):
        if kind!='logo': raise HTTPException(400,'SVG مسموح للشعار فقط')
        key=await run_in_threadpool(svg_image,b)
        image=Image.open(io.BytesIO(media_bytes(key)))
    else:
        image=open_image(b);key=save_image(image)
    palette=image.resize((100,100)).quantize(colors=6).convert('RGB').getcolors(10000)
    colors=['#%02X%02X%02X'%rgb for count,rgb in sorted(palette,reverse=True) if max(rgb)-min(rgb)>35]
    decoded=False
    if kind=='qr':
        decoded=bool(cv2.QRCodeDetector().detectAndDecode(np.array(image))[0])
    return {'id':key,'colors':colors,'qr_readable':decoded}

def svg_image(b):
    import xml.etree.ElementTree as ET
    try:
        root=ET.fromstring(b)
        if root.tag.split('}')[-1]!='svg': raise ValueError()
        for el in root.iter():
            if el.tag.split('}')[-1] in ['script','foreignObject','image','use','style','a']:raise ValueError()
            for k,v in el.attrib.items():
                if k.lower().startswith('on') or any(t in v.lower() for t in ['url(','http:','https:','file:','javascript:','data:']):raise ValueError()
    except Exception: raise HTTPException(400,'SVG غير آمن؛ استخدم PNG أو JPG أو SVG بسيطًا دون روابط')
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path=os.getenv('SAMAYA_CHROMIUM') or None);page=browser.new_page(viewport={'width':1000,'height':600})
        page.route('**/*',lambda route:route.abort())
        page.set_content('<body style="margin:0">'+ET.tostring(root,encoding='unicode')+'</body>')
        page.locator('svg').evaluate('(s)=>{s.style.width="1000px";s.style.height="600px"}')
        result=page.locator('svg').screenshot();browser.close()
    return save_image(open_image(result))

class Crop(BaseModel):
    image:str
    x:float=Field(ge=0,le=1)
    y:float=Field(ge=0,le=1)
    width:float=Field(gt=0,le=1)
    height:float=Field(gt=0,le=1)

@app.post('/api/crop')
def crop_image(s:Crop):
    if s.x+s.width>1.001 or s.y+s.height>1.001:raise HTTPException(422,'حدود القص خارج الصورة')
    image=Image.open(io.BytesIO(media_bytes(s.image)));w,h=image.size
    if s.width*w<10 or s.height*h<10:raise HTTPException(422,'منطقة القص صغيرة جدًا')
    return {'id':save_image(image.crop((round(s.x*w),round(s.y*h),round((s.x+s.width)*w),round((s.y+s.height)*h))))}

class ArabicNameRequest(BaseModel):
    image:str

@app.post('/api/arabic-name')
async def read_arabic_name(s:ArabicNameRequest):
    from name_ocr import recognize_name
    image=Image.open(io.BytesIO(media_bytes(s.image))).convert('RGB')
    try:native='ara' in pytesseract.get_languages(config='')
    except Exception:native=False
    return await run_in_threadpool(recognize_name,image,native=native,focused=True)

class Pilgrim(BaseModel):
    id:Optional[str]=None
    name:str=Field('',max_length=90)
    passport:str=Field('',max_length=20)
    photo:Optional[str]=None
    source:Optional[str]=None
    hotel:str=Field('',max_length=70)
    supervisor:str=Field('',max_length=70)
    phone:str=Field('',max_length=25)
    qr:Optional[str]=None
    campaign:str=Field('الحملة الرئيسية',min_length=1,max_length=80)
    approved:bool=False
    reviewed:bool=False
    name_confidence:float=0
    name_status:str=''
    confidence:float=0
    mrz_valid:bool=False
    ocr_status:str='يدوي'
    photo_x:float=Field(50,ge=0,le=100)
    photo_y:float=Field(50,ge=0,le=100)

@app.get('/api/pilgrims')
def list_pilgrims():
    with connection() as c:return [json.loads(r[0]) for r in c.execute('SELECT data FROM pilgrims ORDER BY rowid DESC')]

@app.post('/api/pilgrims')
def save_pilgrim(p:Pilgrim):
    p.passport=p.passport.strip().upper();p.name=p.name.strip();p.id=p.id or uuid.uuid4().hex
    if p.approved:
        if not p.reviewed:raise HTTPException(422,'أكد مراجعة البيانات يدويًا')
        if not all([p.name,p.passport,p.photo,p.hotel,p.supervisor,p.phone]):raise HTTPException(422,'أكمل الاسم والجواز والصورة والفندق وبيانات المشرف')
        if not re.fullmatch('[A-Z0-9]{5,20}',p.passport):raise HTTPException(422,'رقم الجواز يجب أن يحتوي على 5 إلى 20 حرفًا لاتينيًا أو رقمًا')
        if not re.search('[\u0621-\u064A]',p.name):raise HTTPException(422,'أدخل الاسم العربي')
        if not(p.qr or get_settings().get('qr')):raise HTTPException(422,'ارفع رمز الفندق قبل الاعتماد')
    for key in [p.photo,p.source,p.qr]:
        if key:media_bytes(key)
    try:
        with connection() as c:
            c.execute('INSERT INTO pilgrims VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET passport=excluded.passport,data=excluded.data',(p.id,p.passport or None,p.model_dump_json()))
    except sqlite3.IntegrityError:raise HTTPException(409,'رقم الجواز موجود مسبقًا؛ عدّل السجل الموجود أو صحّح الرقم')
    return p

@app.delete('/api/pilgrims/{pid}')
def delete_pilgrim(pid:str):
    with connection() as c:c.execute('DELETE FROM pilgrims WHERE id=?',(pid,))
    for jid,job in list(JOBS.items()):
        if job.get('record',{}).get('id')==pid:JOBS.pop(jid,None)
    garbage_collect();return {'ok':True}

def garbage_collect():
    with connection() as c:
        used=set();items=[json.loads(r[0]) for r in c.execute('SELECT data FROM pilgrims')]+[get_settings()]
        for r in items:
            used.update(r[k] for k in ['photo','source','qr','logo'] if r.get(k))
        for r in c.execute('SELECT id FROM media').fetchall():
            if r[0] not in used:c.execute('DELETE FROM media WHERE id=?',(r[0],))

@app.delete('/api/pilgrims/{pid}/source')
def delete_source(pid:str):
    with connection() as c:
        r=c.execute('SELECT data FROM pilgrims WHERE id=?',(pid,)).fetchone()
        if not r:raise HTTPException(404,'السجل غير موجود')
        d=json.loads(r[0]);d['source']=None;c.execute('UPDATE pilgrims SET data=? WHERE id=?',(json.dumps(d),pid))
    for job in JOBS.values():
        if job.get('record',{}).get('id')==pid:job['record']['source']=None
    garbage_collect();return {'ok':True}

class CampaignDelete(BaseModel):
    campaign:str
    confirmation:str

@app.post('/api/campaign/delete')
def delete_campaign(s:CampaignDelete):
    if any(j['status'] in ['انتظار','معالجة'] for j in JOBS.values()):raise HTTPException(409,'انتظر انتهاء مهام الاستخراج قبل حذف الحملة')
    if s.confirmation!=s.campaign:raise HTTPException(422,'اكتب اسم الحملة للتأكيد')
    with connection() as c:
        for r in c.execute('SELECT id,data FROM pilgrims').fetchall():
            if json.loads(r[1]).get('campaign')==s.campaign:c.execute('DELETE FROM pilgrims WHERE id=?',(r[0],))
    for jid,job in list(JOBS.items()):
        if job.get('record',{}).get('campaign')==s.campaign:JOBS.pop(jid,None)
    garbage_collect();return {'ok':True}

def process_job(jid,b):
    job=JOBS[jid]
    try:
        job.update(status='معالجة',progress=10)
        if b.startswith(b'%PDF'):
            doc=fitz.open(stream=b,filetype='pdf')
            if doc.is_encrypted or len(doc)>10:raise ValueError('PDF مشفر أو يتجاوز 10 صفحات')
            best=None;score=-1
            for i,page in enumerate(doc):
                if page.rect.width*page.rect.height>10_000_000:raise ValueError('أبعاد PDF كبيرة جدًا')
                pix=page.get_pixmap(matrix=fitz.Matrix(min(2,2400/max(page.rect.width,page.rect.height)),min(2,2400/max(page.rect.width,page.rect.height))))
                image=Image.open(io.BytesIO(pix.tobytes('png'))).convert('RGB')
                # Real OCR ranks pages by MRZ, passport and name evidence.
                try:
                    result,normalized,face=extract(image)
                    rank=int(result['mrz_valid'])*200+int(bool(result['passport']))*80+int(bool(result['name']))*30+result['confidence']
                    candidate=(result,normalized,face)
                except Exception:
                    rank=0;candidate=({'name':'','passport':'','confidence':0,'mrz_valid':False},image,None)
                if rank>score:best=candidate;score=rank
                job['progress']=10+round(70*(i+1)/len(doc))
            doc.close()
            if best is None:raise ValueError('PDF فارغ')
            result,image,face=best
            warning='' if score>0 else 'تعذر OCR؛ حدّد صفحة الجواز يدويًا أو ارفعها كصورة'
        else:
            image=open_image(b)
            try:result,image,face=extract(image);warning=''
            except Exception as e:result={'name':'','passport':'','confidence':0,'mrz_valid':False};face=portrait(image);warning='تعذر تشغيل OCR. شغّل setup.bat لتثبيت المحرك المحلي ونماذج اللغات؛ راجع البيانات يدويًا.'
        source=save_image(image);photo=save_image(face) if face is not None else None
        settings=get_settings()
        record=Pilgrim(**result,source=source,photo=photo,hotel=settings.get('hotel',''),supervisor=settings.get('supervisor',''),phone=settings.get('phone',''),qr=settings.get('qr'),campaign=settings.get('campaign','الحملة الرئيسية'),ocr_status='مراجعة مطلوبة' if not warning else 'استخراج غير مكتمل')
        try:saved=save_pilgrim(record);job.update(record=saved.model_dump())
        except HTTPException as e:
            if e.status_code!=409:raise
            # Preserve the conflicting draft without approving or discarding it.
            number=record.passport;record.passport='';saved=save_pilgrim(record)
            job.update(record=saved.model_dump());warning=f'تعارض الجواز {number}؛ حُفظت مسودة دون رقم، راجع السجل الموجود'
        job.update(status='مكتمل',progress=100,warning=warning or ('ثقة الاستخراج منخفضة؛ راجع جميع الحقول والصورة' if result['confidence']<80 else 'راجع الاسم والجواز والصورة قبل الاعتماد'))
    except Exception as e:job.update(status='فشل',progress=100,warning=e.detail if isinstance(e,HTTPException) else 'تعذر معالجة الملف؛ تحقق من سلامة الصورة أو PDF وحجمه وعدد صفحاته ثم أعد المحاولة')

@app.post('/api/passports')
async def passports(files:list[UploadFile]=File(...)):
    if not 1<=len(files)<=30:raise HTTPException(400,'ارفع من 1 إلى 30 ملفًا في الدفعة')
    if sum(j['status'] in ['انتظار','معالجة'] for j in JOBS.values())+len(files)>60:raise HTTPException(429,'انتظر انتهاء الدفعة الحالية')
    pending=[]
    for file in files:
        b=await uploaded_bytes(file)
        if not b.startswith(b'%PDF'):open_image(b)
        pending.append((file.filename,b))
    ids=[]
    for name,b in pending:
        jid=uuid.uuid4().hex;JOBS[jid]={'id':jid,'filename':name,'status':'انتظار','progress':0};ids.append(jid)
        POOL.submit(process_job,jid,b)
    return {'ids':ids}

@app.get('/api/jobs')
def jobs():return list(JOBS.values())[-100:]

@app.post('/api/reextract/{pid}')
def reextract(pid:str):
    r=next((p for p in list_pilgrims() if p['id']==pid),None)
    if not r or not r.get('source'):raise HTTPException(404,'صورة الجواز الأصلية غير موجودة')
    # Queue creates a separate review draft and never overwrites approved records.
    jid=uuid.uuid4().hex;JOBS[jid]={'id':jid,'filename':'إعادة استخراج','status':'انتظار','progress':0}
    POOL.submit(process_job,jid,media_bytes(r['source']));return {'id':jid}

class PrintRequest(BaseModel):
    records:list[Pilgrim]=Field(default_factory=list,max_length=200)
    ids:list[str]=Field(default_factory=list,max_length=200)
    mode:str='cr80'
    test:bool=False


def print_html(s,approved=False):
    if s.mode not in ['cr80','a4']:raise HTTPException(422,'مقاس طباعة غير مدعوم')
    records=[p.model_dump() for p in s.records]
    if approved:
        # Export resolves saved approved data only, ignoring client-supplied records.
        records=[p for p in list_pilgrims() if p['id'] in s.ids]
        if len(records)!=len(set(s.ids)) or any(not p['approved'] for p in records):raise HTTPException(422,'اختر بطاقات محفوظة ومعتمدة فقط')
    if not records and not s.test:raise HTTPException(422,'اختر بطاقة واحدة على الأقل')
    return render(records,get_settings(),media_bytes,s.mode,s.test)

@app.post('/api/print-layout',response_class=HTMLResponse)
def print_layout(s:PrintRequest):return print_html(s,approved=True)

@app.post('/api/preview',response_class=HTMLResponse)
def preview(s:PrintRequest):return print_html(s)


def create_pdf(html):
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        try:browser=p.chromium.launch(executable_path=os.getenv('SAMAYA_CHROMIUM') or None)
        except Exception:raise HTTPException(503,'محرك PDF الخادمي غير متاح؛ استخدم زر تنزيل PDF في الواجهة الذي يعمل داخل المتصفح')
        page=browser.new_page()
        page.route('**/*',lambda route:route.abort())
        page.set_content(html,wait_until='load');page.evaluate('document.fonts.ready')
        if page.locator('.name,.details').evaluate_all('(els)=>els.some(e=>e.scrollHeight>e.clientHeight+1||e.scrollWidth>e.clientWidth+1)'):
            browser.close();raise HTTPException(422,'الاسم يتجاوز المساحة المتاحة؛ اختصره بعد المراجعة')
        pdf=page.pdf(prefer_css_page_size=True,print_background=True)
        browser.close()
        from pdf_utils import exact_page_boxes
        return exact_page_boxes(pdf,a4='size:A4' in html)


@app.post('/api/pdf')
async def pdf(s:PrintRequest):
    html=print_html(s,approved=True)
    return Response(await run_in_threadpool(create_pdf,html),media_type='application/pdf',headers={'Content-Disposition':'attachment; filename="samaya-cards.pdf"'})

@app.get('/api/export.csv')
def export_csv():
    out=io.StringIO();writer=csv.writer(out);writer.writerow(['الاسم','رقم الجواز','الفندق','المشرف','الهاتف','الحملة','معتمد'])
    for r in list_pilgrims():
        vals=[r.get(k,'') for k in ['name','passport','hotel','supervisor','phone','campaign','approved']]
        writer.writerow(["'"+str(v) if str(v).startswith(('=','+','-','@','\t','\r')) else v for v in vals])
    return Response(('\ufeff'+out.getvalue()).encode('utf-8'),media_type='text/csv',headers={'Content-Disposition':'attachment; filename="samaya.csv"'})

class BackupRequest(BaseModel):
    password:str=Field('',max_length=200)

def key_for(password,salt):return Scrypt(salt=salt,length=32,n=2**14,r=8,p=1).derive(password.encode())

@app.post('/api/backup')
def backup(s:BackupRequest):
    with LOCK:
        temp=sqlite3.connect(':memory:')
        with connection() as c:c.backup(temp)
        # iterdump is data-only on restore: never executed from user input.
        payload=json.dumps({'version':1,'records':[json.loads(r[0]) for r in temp.execute('SELECT data FROM pilgrims')],'settings':json.loads(temp.execute('SELECT data FROM settings WHERE id=1').fetchone()[0]),'media':[{'id':r[0],'data':base64.b64encode(r[1]).decode()} for r in temp.execute('SELECT id,data FROM media')]}).encode()
        temp.close()
    if s.password:
        salt=os.urandom(16);nonce=os.urandom(12);payload=b'SAMAYA1'+salt+nonce+AESGCM(key_for(s.password,salt)).encrypt(nonce,payload,b'SAMAYA1')
    return Response(payload,media_type='application/octet-stream',headers={'Content-Disposition':'attachment; filename="samaya.backup"'})

@app.post('/api/restore')
async def restore(file:UploadFile=File(...),password:str=Form(''),confirmation:str=Form('')):
    if confirmation!='استعادة':raise HTTPException(422,'اكتب استعادة لتأكيد استبدال البيانات')
    if any(j['status'] in ['انتظار','معالجة'] for j in JOBS.values()):raise HTTPException(409,'انتظر انتهاء استخراج الجوازات قبل الاستعادة')
    b=await file.read(250*1024*1024+1)
    if len(b)>250*1024*1024:raise HTTPException(413,'النسخة الاحتياطية أكبر من 250 ميجابايت')
    try:
        if b.startswith(b'SAMAYA1'):b=AESGCM(key_for(password,b[7:23])).decrypt(b[23:35],b[35:],b'SAMAYA1')
        d=json.loads(b);assert d['version']==1
        records=[Pilgrim(**r) for r in d['records']];s=Settings(**d['settings'])
        media=[(m['id'],base64.b64decode(m['data'],validate=True)) for m in d['media']]
        assert len({r.id for r in records})==len(records)
        assert all(r.id and re.fullmatch('[a-f0-9]{32}',r.id) for r in records)
        assert all(not r.passport or r.passport==r.passport.strip().upper() for r in records)
        assert all(not r.approved or (r.reviewed and all([r.name,r.passport,r.photo,r.hotel,r.supervisor,r.phone,r.qr or s.qr])) for r in records)
        keys={m[0] for m in media}
        for key,data in media:
            assert re.fullmatch('[a-f0-9]{32}',key);open_image(data)
        for r in [p.model_dump() for p in records]+[s.model_dump()]:
            assert all(not r.get(k) or r[k] in keys for k in ['photo','source','qr','logo'])
        assert all(re.fullmatch('#[0-9a-fA-F]{6}',col) for col in [s.primary,s.accent,s.secondary])
        with LOCK,connection() as c:
            c.execute('DELETE FROM pilgrims');c.execute('DELETE FROM media')
            c.executemany('INSERT INTO media VALUES(?,?)',media)
            for r in records:c.execute('INSERT INTO pilgrims VALUES(?,?,?)',(r.id,r.passport or None,r.model_dump_json()))
            c.execute('UPDATE settings SET data=? WHERE id=1',(s.model_dump_json(),))
    except Exception:raise HTTPException(400,'النسخة غير صالحة أو كلمة المرور غير صحيحة؛ لم تُستبدل البيانات')
    JOBS.clear()
    return {'ok':True}
