import re
import os
import io
import json
import shutil
import subprocess
import tempfile
from pathlib import Path
import cv2
import numpy as np
import pytesseract
from PIL import Image

def check_digit(s):
    chars='0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    return str(sum((chars.index(c) if c in chars else 0)*[7,3,1][i%3] for i,c in enumerate(s))%10)

def parse_text(text):
    lines=[re.sub(r'[^A-Z0-9<]','',s.upper()) for s in text.splitlines()]
    for line in lines:
        if len(line)>=28 and re.match(r'^[A-Z0-9<]{9}[0-9][A-Z<]{3}[0-9]{6}',line):
            number=line[:9]
            return {'passport':number.replace('<',''),'mrz_valid':check_digit(number)==line[9]}
    match=re.search(r'\b[A-Z]{1,3}[0-9]{5,9}\b',text.upper()) or re.search(r'\b[0-9]{7,9}\b',text)
    return {'passport':match.group() if match else '', 'mrz_valid':False}

def arabic_name(text):
    from names import select_name
    return select_name([{'text':line,'confidence':85} for line in text.splitlines()])['name']


def normalize(image):
    arr=cv2.cvtColor(np.array(image.convert('RGB')),cv2.COLOR_RGB2BGR)
    try:
        osd=pytesseract.image_to_osd(arr,output_type=pytesseract.Output.DICT)
        rotation=osd.get('rotate',0)
        if rotation: arr=np.array(Image.fromarray(cv2.cvtColor(arr,cv2.COLOR_BGR2RGB)).rotate(-rotation,expand=True))[:,:,::-1]
    except (pytesseract.TesseractError,pytesseract.TesseractNotFoundError): pass
    gray=cv2.cvtColor(arr,cv2.COLOR_BGR2GRAY)
    coords=np.column_stack(np.where(cv2.threshold(gray,0,255,cv2.THRESH_BINARY_INV+cv2.THRESH_OTSU)[1]>0))
    if len(coords)>20:
        angle=cv2.minAreaRect(coords[:,::-1].astype(np.float32))[-1]
        if angle>45: angle-=90
        if 0.3<abs(angle)<12:
            h,w=gray.shape; arr=cv2.warpAffine(arr,cv2.getRotationMatrix2D((w/2,h/2),angle,1),(w,h),borderValue=(255,255,255))
    return Image.fromarray(cv2.cvtColor(arr,cv2.COLOR_BGR2RGB))

def portrait(image):
    arr=np.array(image.convert('RGB'));gray=cv2.cvtColor(arr,cv2.COLOR_RGB2GRAY)
    detector=cv2.CascadeClassifier(cv2.data.haarcascades+'haarcascade_frontalface_default.xml')
    faces=detector.detectMultiScale(gray,1.1,5,minSize=(40,40))
    if not len(faces): return None
    x,y,w,h=max(faces,key=lambda r:r[2]*r[3]); H,W=gray.shape
    return image.crop((max(0,x-int(w*.35)),max(0,y-int(h*.45)),min(W,x+int(w*1.35)),min(H,y+int(h*1.65))))

def extract(image):
    try:languages=pytesseract.get_languages(config='')
    except Exception:languages=[]
    if not {'ara','eng'}.issubset(languages):return extract_wasm(image)
    image=normalize(image)
    gray=cv2.cvtColor(np.array(image),cv2.COLOR_RGB2GRAY)
    gray=cv2.createCLAHE(2.0,(8,8)).apply(gray)
    data=pytesseract.image_to_data(gray,lang='ara+eng',config='--psm 3',output_type=pytesseract.Output.DICT)
    text=pytesseract.image_to_string(gray,lang='ara+eng',config='--psm 3')
    mrz=pytesseract.image_to_string(gray[int(gray.shape[0]*.74):],lang='eng',config='--psm 6 -c tessedit_char_whitelist=ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789<')
    values=[float(v) for v in data['conf'] if float(v)>=0]
    result=parse_text(mrz+'\n'+text)
    result.update(name=arabic_name(text),confidence=round(sum(values)/len(values)) if values else 0)
    from name_ocr import recognize_name
    result.update(recognize_name(image,native=True))
    return result,image,portrait(image)


def wasm_ready():
    root=Path(__file__).resolve().parents[1]
    return bool((os.getenv('SAMAYA_NODE') or shutil.which('node')) and (root/'node_modules/tesseract.js').exists() and all((root/'backend/tessdata'/(lang+'.traineddata')).exists() for lang in ['ara','eng']))

def extract_wasm(image):
    if not wasm_ready():raise RuntimeError('شغّل setup.bat لتثبيت محرك OCR المحلي ونماذج العربية والإنجليزية')
    root=Path(__file__).resolve().parents[1]
    image=normalize(image)
    gray=cv2.cvtColor(np.array(image),cv2.COLOR_RGB2GRAY)
    enhanced=Image.fromarray(cv2.createCLAHE(2.0,(8,8)).apply(gray))
    with tempfile.TemporaryDirectory(prefix='samaya-ocr-') as folder:
        candidates=[]
        for angle in [0,90,180,270]:
            rotated=enhanced.rotate(angle,expand=True)
            full=Path(folder)/f'page-{angle}.png';mrz=Path(folder)/f'mrz-{angle}.png'
            rotated.save(full);rotated.crop((0,int(rotated.height*.74),rotated.width,rotated.height)).save(mrz)
            candidates.append({'rotation':angle,'full':str(full),'mrz':str(mrz),'face':portrait(image.rotate(angle,expand=True)) is not None})
        manifest=Path(folder)/'inputs.json';manifest.write_text(json.dumps(candidates),encoding='utf-8')
        process=subprocess.run([os.getenv('SAMAYA_NODE') or shutil.which('node'),str(root/'scripts/ocr_worker.cjs'),str(manifest)],capture_output=True,text=True,encoding='utf-8',timeout=180,cwd=str(root))
        if process.returncode:raise RuntimeError('تعذر تشغيل OCR المحلي؛ تحقق من نماذج اللغات وحزم Node.js')
        data=json.loads(process.stdout)
    best=None;best_score=-1
    for reading in data['readings']:
        result=parse_text(reading['mrz']+'\n'+reading['text'])
        result.update(name=arabic_name(reading['text']),confidence=round(reading['confidence']))
        score=200*int(result['mrz_valid'])+50*int(bool(result['passport']))+50*int(reading['candidate']['face'])+10*int(bool(result['name']))+result['confidence']
        if score>best_score:best=(result,reading['candidate']['rotation']);best_score=score
    if best is None:raise RuntimeError('لم يُرجع محرك OCR نصًا قابلًا للمراجعة')
    result,angle=best;image=image.rotate(angle,expand=True)
    from name_ocr import recognize_name
    result.update(recognize_name(image))
    return result,image,portrait(image)
