"""Exact physical page boxes, independent of Chromium's CSS rounding."""
import io
from pypdf import PdfReader,PdfWriter
from pypdf.generic import RectangleObject

def exact_page_boxes(pdf:bytes,a4:bool=False)->bytes:
    width,height=(210,297) if a4 else (85.60,53.98)
    writer=PdfWriter()
    for page in PdfReader(io.BytesIO(pdf)).pages:
        page.mediabox=RectangleObject([0,0,width*72/25.4,height*72/25.4])
        page.cropbox=RectangleObject([0,0,width*72/25.4,height*72/25.4])
        writer.add_page(page)
    stream=io.BytesIO();writer.write(stream);return stream.getvalue()
