import base64
from html import escape
from pathlib import Path

CSS=(Path(__file__).parents[1]/'shared/card.css').read_text(encoding='utf-8')

def image_url(blob):
    return 'data:image/png;base64,'+base64.b64encode(blob).decode() if blob else ''

def render(records,settings,media,mode='cr80',test=False):
    def esc(v): return escape(str(v or ''),quote=True)
    def img(key,cls,style=''):
        b=media(key) if key else None
        return f'<img class="{cls}" style="{style}" src="{image_url(b)}">' if b else f'<div class="{cls} missing">غير مرفق</div>'
    font=Path(__file__).parent/'fonts/Cairo.ttf'
    font_url='data:font/ttf;base64,'+base64.b64encode(font.read_bytes()).decode() if font.exists() else ''
    css=CSS.replace('FONT_URL',font_url)
    if mode=='a4': css+='@page{size:A4;margin:10mm}.sheet{grid-template-columns:repeat(2,85.60mm);gap:1.5mm 5mm}'
    else: css+='@page{size:85.60mm 53.98mm;margin:0}.card{break-after:page}'
    primary=settings.get('primary','#329DD0');accent=settings.get('accent','#F68B50');secondary=settings.get('secondary','#666666')
    out=[]
    for r in records:
        logo=settings.get('logo')
        if not logo and any((Path(__file__).parents[1]/('frontend/public/assets/samaya-logo.'+ext)).exists() for ext in ['jpg','png']):
            logo='original'
        photo_style=f"object-position:{r.get('photo_x',50)}% {r.get('photo_y',50)}%;"
        photo=img(r.get('photo'),'portrait',photo_style)
        template=(Path(__file__).parents[1]/'shared/card.html').read_text(encoding='utf-8')
        values={k:esc(r.get(k)) for k in ['name','passport','hotel','supervisor','phone']}
        values.update(logo=img(logo,'logo'),photo=photo,qr=img(r.get('qr') or settings.get('qr'),'qr'))
        for key,value in values.items():template=template.replace('{{'+key+'}}',value)
        out.append(template)
    ruler='<div class="ruler">'+''.join(f'<span style="left:{i}mm">{i}</span>' for i in range(0,101,10))+'</div><p>المسطرة 100 ملم — اطبع بالحجم الفعلي 100٪ دون ملاءمة الصفحة.</p>' if test else ''
    return f'<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><style>{css}</style><body style="--primary:{primary};--accent:{accent};--secondary:{secondary};--logo:{settings.get("logo_width",28)}mm"><main class="sheet">'+''.join(out)+'</main>'+ruler+'</body></html>'
