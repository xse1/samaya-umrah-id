"""Conservative Arabic name selection from Arabic-only OCR lines."""
import re
import unicodedata

NAME_LABEL=re.compile(r'(?:الاسم(?:\s*الكامل)?|الاسماء|الأسماء|اسم\s+(?:حامل\s+الجواز|العائلة|الأب|الاب)|اللقب)\s*[:：\-]?')
OTHER_FIELDS=re.compile(r'الجمهورية|جمهورية|المملكة|وزارة|جواز|الجنسية|الميلاد|الإصدار|الاصدار|الصلاحية|الانتهاء|تاريخ|مكان|محل|المهنة|الجنس|السلطة|التوقيع|متزوج|متزوجة|سياحة|اختبار')

def clean_candidate(text):
    text=unicodedata.normalize('NFKC',text)
    text=re.sub(r'[\u064B-\u065F\u0670\u0640]','',text)
    text=NAME_LABEL.sub('',text).strip(' :،.-')
    words=re.findall(r'[\u0621-\u064A]+',text)
    if not 2<=len(words)<=8 or OTHER_FIELDS.search(text):return ''
    if any(len(w)<2 or w in {'ال','لل','دن'} for w in words):return ''
    arabic=' '.join(words)
    if len(arabic)<7 or len(arabic)>90:return ''
    # Mixed labels, dates and English transliteration are not name evidence.
    visible=re.sub(r'[\s:،.\-]','',text)
    if sum(len(w) for w in words)/max(1,len(visible))<.85:return ''
    return arabic

def name_key(text):
    # Treat common OCR spelling/spacing variants as agreement, without changing
    # the selected Arabic spelling or using the Latin MRZ to construct a name.
    return re.sub(r'\s+','',text).translate(str.maketrans({'أ':'ا','إ':'ا','آ':'ا','ى':'ي'}))

def select_name(lines,focused=False):
    """Coordinates are normalized to the full passport image (0..1)."""
    anchors=[line for line in lines if NAME_LABEL.search(line['text']) and float(line.get('confidence',0))>=35]
    ranked=[]
    for line in lines:
        name=clean_candidate(line['text']);confidence=float(line.get('confidence',0))
        if not name or confidence<55:continue
        box=line.get('box',[0,0,1,1]);near=focused
        for anchor in anchors:
            a=anchor.get('box',[0,0,1,1])
            horizontal=min(box[2],a[2])-max(box[0],a[0])
            vertical=abs((box[1]+box[3]-a[1]-a[3])/2)
            if (horizontal>0 or abs(box[2]-a[2])<.15) and vertical<.11:near=True;break
        # Without a field anchor, only a clear multi-word Arabic line is accepted.
        if not near and (confidence<78 or len(name.split())<3):continue
        score=confidence+(25 if near else 0)+min(len(name.split()),5)*2
        ranked.append((score,name,round(confidence)))
    if not ranked:return {'name':'','name_confidence':0,'name_status':'تعذر التحقق من الاسم العربي؛ أدخله يدويًا من الجواز'}
    ranked.sort(reverse=True)
    best=ranked[0]
    # Close, conflicting readings must not be silently substituted for a name.
    rivals=[r for r in ranked[1:] if name_key(r[1])!=name_key(best[1]) and r[0]>=best[0]-4 and name_key(r[1]) not in name_key(best[1]) and name_key(best[1]) not in name_key(r[1])]
    if rivals:return {'name':'','name_confidence':best[2],'name_status':'قراءات عربية متعارضة؛ راجع الاسم من الجواز'}
    return {'name':best[1],'name_confidence':best[2],'name_status':'اسم عربي مستخرج؛ يلزم تأكيده من الجواز'}
