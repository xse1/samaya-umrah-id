const fs=require('fs');
const path=require('path');
const {createWorker,OEM}=require('tesseract.js');
(async()=>{
  const best=path.resolve(__dirname,'../backend/tessdata_arabic');
  const models=fs.existsSync(path.join(best,'ara.traineddata'))?best:path.resolve(__dirname,'../backend/tessdata');
  if(!fs.existsSync(path.join(models,'ara.traineddata')))throw Error('Local Arabic model missing');
  const inputs=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
  const worker=await createWorker('ara',OEM.LSTM_ONLY,{langPath:models,gzip:false,cacheMethod:'none',logger:()=>{}});
  try{
    const lines=[];
    for(const input of inputs){
      await worker.setParameters({tessedit_pageseg_mode:String(input.psm),preserve_interword_spaces:'1',user_defined_dpi:'300'});
      const {data}=await worker.recognize(input.file,{}, {blocks:true,text:true});
      for(const block of data.blocks||[])for(const paragraph of block.paragraphs||[])for(const line of paragraph.lines||[]){
        const words=(line.words||[]).filter(w=>/[\u0621-\u064A]/.test(w.text));
        if(!words.length)continue;
        const confidence=words.reduce((a,w)=>a+w.confidence,0)/words.length;
        const b=line.bbox,[x,y,w,h]=input.region;
        lines.push({text:line.text,confidence,box:[x+b.x0/input.width*w,y+b.y0/input.height*h,x+b.x1/input.width*w,y+b.y1/input.height*h]});
      }
    }
    // Re-read likely name lines alone, without neighbouring English or field labels.
    const full=inputs[0];
    const candidates=lines.filter(line=>{
      const words=line.text.match(/[\u0621-\u064A]+/g)||[];
      return words.length>=3&&words.length<=8&&line.confidence>=55&&!/الجنسية|الميلاد|الجمهورية|جواز|تاريخ|المهنة|الصلاحية|الإصدار/.test(line.text);
    }).sort((a,b)=>b.confidence-a.confidence).slice(0,3);
    await worker.setParameters({tessedit_pageseg_mode:'7'});
    for(const candidate of candidates){
      const [x,y,w,h]=full.region,b=candidate.box;
      const left=Math.max(0,Math.floor((b[0]-x)/w*full.width)-12);
      const top=Math.max(0,Math.floor((b[1]-y)/h*full.height)-12);
      const right=Math.min(full.width,Math.ceil((b[2]-x)/w*full.width)+12);
      const bottom=Math.min(full.height,Math.ceil((b[3]-y)/h*full.height)+12);
      if(right<=left||bottom<=top)continue;
      const {data}=await worker.recognize(full.file,{rectangle:{left,top,width:right-left,height:bottom-top}},{text:true});
      lines.push({text:data.text,confidence:data.confidence,box:b});
    }
    process.stdout.write(JSON.stringify(lines));
  }finally{await worker.terminate()}
})().catch(e=>{process.stderr.write(String(e.message));process.exitCode=1});
