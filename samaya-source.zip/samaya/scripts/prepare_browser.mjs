import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const req=createRequire(path.join(root,'frontend/package.json'));
async function ensureModel(relative,url){
 const target=path.join(root,relative);if(fs.existsSync(target))return;
 const response=await fetch(url,{signal:AbortSignal.timeout(180000)});
 if(!response.ok)throw Error('Model download failed: '+response.status);
 fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,Buffer.from(await response.arrayBuffer()));
}
await Promise.all([
 ensureModel('backend/tessdata/eng.traineddata','https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/eng.traineddata'),
 ensureModel('backend/tessdata_arabic/ara.traineddata','https://raw.githubusercontent.com/tesseract-ocr/tessdata_best/main/ara.traineddata')
]);
const publicDir=path.join(root,'frontend/public-browser');
fs.mkdirSync(publicDir,{recursive:true});
function copy(source,name){fs.copyFileSync(source,path.join(publicDir,name))}
copy(req.resolve('tesseract.js/dist/worker.min.js'),'worker.min.js');
const tessRequire=createRequire(req.resolve('tesseract.js/package.json'));
const core=path.dirname(tessRequire.resolve('tesseract.js-core/package.json'));
for(const file of fs.readdirSync(core))if(file.endsWith('.wasm')||file.endsWith('.wasm.js'))copy(path.join(core,file),file);
copy(req.resolve('@techstark/opencv-js/dist/opencv.js'),'opencv.js');
copy(path.join(root,'shared/haarcascade_frontalface_default.xml'),'haarcascade_frontalface_default.xml');
copy(path.join(root,'backend/tessdata/eng.traineddata'),'eng.traineddata');
copy(path.join(root,'backend/tessdata_arabic/ara.traineddata'),'ara.traineddata');
copy(path.join(root,'backend/tessdata/LICENSE'),'OCR-LICENSE.txt');
for(const file of ['Cairo.ttf','OFL.txt'])copy(path.join(root,'backend/fonts',file),file);
const logo=path.join(root,'frontend/public/assets/samaya-logo.png');if(fs.existsSync(logo))copy(logo,'samaya-logo.png');
fs.writeFileSync(path.join(publicDir,'.nojekyll'),'');
console.log('Browser OCR assets prepared locally; no private data copied.');

fs.copyFileSync(path.join(root,'shared/browser-sw.js'),path.join(publicDir,'sw.js'));
