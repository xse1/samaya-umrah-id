"""Download local language files after Tesseract has been installed by the user."""
import os
import shutil
from pathlib import Path
from urllib.request import urlopen
root=Path(__file__).resolve().parents[1]
target=root/'backend/tessdata';target.mkdir(exist_ok=True)
for language in ['ara','eng','osd']:
    p=target/(language+'.traineddata')
    if not p.exists():
        print('Downloading OCR model:',language)
        with urlopen('https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/'+p.name,timeout=120) as r:p.write_bytes(r.read())
license_path=target/'LICENSE'
if not license_path.exists():
    with urlopen('https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/LICENSE',timeout=60) as r:license_path.write_bytes(r.read())
print('Models saved locally. The WebAssembly engine uses them offline; native Tesseract is optional.')

# Higher-accuracy Arabic model, used only for dedicated name recognition.
best=root/'backend/tessdata_arabic';best.mkdir(exist_ok=True)
model=best/'ara.traineddata'
if not model.exists():
    print('Downloading high-accuracy Arabic model')
    with urlopen('https://raw.githubusercontent.com/tesseract-ocr/tessdata_best/main/ara.traineddata',timeout=180) as r:model.write_bytes(r.read())
(best/'LICENSE').write_bytes((target/'LICENSE').read_bytes())
