import time
from urllib.request import urlopen
for _ in range(60):
    try:
        for url in ['http://127.0.0.1:8000/api/health','http://127.0.0.1:5173/']:
            with urlopen(url,timeout=1) as response:
                if response.status!=200:raise RuntimeError()
        print('Samaya is ready.');break
    except Exception:time.sleep(.5)
else:raise SystemExit('Server did not start. Check the API and UI windows, then restart.')
