// All recognition runs locally with explicit local models and packaged WASM.
const path=require('path');
const fs=require('fs');
const {createWorker,OEM}=require('tesseract.js');
(async()=>{
  const modelPath=path.resolve(__dirname,'../backend/tessdata');
  for(const name of ['ara','eng']) if(!fs.existsSync(path.join(modelPath,name+'.traineddata'))) throw Error('Local OCR model missing: '+name);
  const candidates=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
  let worker;
  try{
    worker=await createWorker(['ara','eng'],OEM.LSTM_ONLY,{langPath:modelPath,gzip:false,cacheMethod:'none',logger:()=>{}});
    const readings=[];
    for(const candidate of candidates){
      const {data}=await worker.recognize(candidate.full);
      readings.push({candidate,text:data.text,confidence:data.confidence});
      if(candidate.rotation===0&&data.confidence>=55)break;
    }
    await worker.reinitialize('eng',OEM.LSTM_ONLY);
    await worker.setParameters({tessedit_pageseg_mode:'6',tessedit_char_whitelist:'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789<'});
    for(const reading of readings){
      const {data}=await worker.recognize(reading.candidate.mrz);
      reading.mrz=data.text;
    }
    process.stdout.write(JSON.stringify({readings}));
  }finally{if(worker)await worker.terminate()}
})().catch(e=>{process.stderr.write(String(e.message));process.exitCode=1});
