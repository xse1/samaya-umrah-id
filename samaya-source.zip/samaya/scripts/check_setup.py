import os
import shutil
from pathlib import Path
import pytesseract
root=Path(__file__).resolve().parents[1]
os.environ['TESSDATA_PREFIX']=str(root/'backend/tessdata')
candidate=os.environ.get('TESSERACT_CMD') or shutil.which('tesseract') or r'C:\Program Files\Tesseract-OCR\tesseract.exe'
pytesseract.pytesseract.tesseract_cmd=candidate
native=False
try:native={'ara','eng'}.issubset(pytesseract.get_languages(config=''))
except Exception:pass
wasm=bool(shutil.which('node') and (root/'node_modules/tesseract.js').exists() and all((root/'backend/tessdata'/(lang+'.traineddata')).exists() for lang in ['ara','eng']))
print('Local OCR ready:',native or wasm,'Engine:','native' if native else 'WebAssembly' if wasm else 'not installed')
print('Original logo:',(root/'frontend/public/assets/samaya-logo.jpg').exists())
if not(native or wasm):raise SystemExit('Run setup.bat again to install OCR dependencies.')
