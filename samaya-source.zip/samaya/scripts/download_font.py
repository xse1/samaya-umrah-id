"""First-install only. The running application makes no external requests."""
from pathlib import Path
from urllib.request import urlopen
root=Path(__file__).resolve().parents[1]
url='https://raw.githubusercontent.com/google/fonts/main/ofl/cairo/'
for name in ['Cairo[slnt,wght].ttf','OFL.txt']:
    target='Cairo.ttf' if name.endswith('.ttf') else name
    path=root/'backend/fonts'/target
    path.parent.mkdir(parents=True,exist_ok=True)
    if not path.exists():
        with urlopen(url+name.replace('[','%5B').replace(']','%5D'),timeout=60) as response:path.write_bytes(response.read())
    frontend=root/'frontend/public/assets'/target
    frontend.parent.mkdir(parents=True,exist_ok=True)
    frontend.write_bytes(path.read_bytes())
print('Arabic font saved locally.')
