@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>&1 || (echo Python 3.12 is required. Install it first. & pause & exit /b 1)
where npm >nul 2>&1 || (echo Node.js 22 LTS is required. Install it first. & pause & exit /b 1)
py -3.12 -m venv .venv
if errorlevel 1 goto fail
.venv\Scripts\python -m pip install -r backend\requirements.txt
if errorlevel 1 goto fail
.venv\Scripts\python -m playwright install chromium
if errorlevel 1 goto fail
.venv\Scripts\python scripts\download_font.py
if errorlevel 1 goto fail
call npm install
if errorlevel 1 goto fail
call npm --prefix frontend install
if errorlevel 1 goto fail
call npm --prefix frontend run build
if errorlevel 1 goto fail
.venv\Scripts\python scripts\setup_ocr.py
if errorlevel 1 goto fail
.venv\Scripts\python scripts\check_setup.py
if errorlevel 1 goto fail
echo Setup finished. Local OCR models and WebAssembly engine are ready. Read README.md.
pause
exit /b 0
:fail
echo Setup failed. Read the error above and run setup.bat again.
pause
exit /b 1
