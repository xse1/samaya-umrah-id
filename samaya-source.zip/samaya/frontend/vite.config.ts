import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
export default defineConfig(({mode})=>({plugins:[react(),tailwindcss()],base:mode==='pages'?'./':'/',publicDir:mode==='pages'?'public-browser':'public',build:{outDir:mode==='pages'?'dist-pages':'dist',rollupOptions:{output:{entryFileNames:'[name]-[hash].js',chunkFileNames:'[name]-[hash].js',assetFileNames:'[name]-[hash][extname]'}}},server:{host:'127.0.0.1',port:5173,strictPort:true,proxy:mode==='pages'?undefined:{'/api':'http://127.0.0.1:8000'}}}));
