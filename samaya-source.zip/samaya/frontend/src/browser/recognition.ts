import {createWorker,OEM,PSM,type Worker} from 'tesseract.js';
import {asset} from './types';
import {canvas} from './images';
type Line={text:string;confidence:number;box:number[]};
const nameLabel=/(?:الاسم(?:\s*الكامل)?|الاسماء|الأسماء|اسم\s+(?:حامل\s+الجواز|العائلة|الأب|الاب)|اللقب)\s*[:：\-]?/g;
const otherFields=/الجمهورية|جمهورية|المملكة|وزارة|جواز|الجنسية|الميلاد|الإصدار|الاصدار|الصلاحية|الانتهاء|تاريخ|مكان|محل|المهنة|الجنس|السلطة|التوقيع|متزوج|متزوجة|سياحة|اختبار/;
function clean(text:string){text=text.normalize('NFKC').replace(/[\u064B-\u065F\u0670\u0640]/g,'').replace(nameLabel,'').trim();const words=text.match(/[\u0621-\u064A]+/g)||[];if(words.length<2||words.length>8||otherFields.test(text)||words.some(w=>w.length<2||['ال','لل','دن'].includes(w)))return '';const out=words.join(' ');if(out.length<7||out.length>90||words.join('').length/Math.max(1,text.replace(/[\s:،.\-]/g,'').length)<.85)return '';return out}
const nameKey=(s:string)=>s.replace(/\s/g,'').replace(/[أإآ]/g,'ا').replace(/ى/g,'ي');
export function chooseName(lines:Line[],focused=false){
 const anchors=lines.filter(l=>/الاسم|اللقب|اسم العائلة/.test(l.text)&&l.confidence>=35),ranked:{name:string;confidence:number;score:number}[]=[];
 for(const line of lines){const name=clean(line.text);if(!name||line.confidence<55)continue;const b=line.box,near=focused||anchors.some(a=>{const v=a.box;return (Math.min(b[2],v[2])-Math.max(b[0],v[0])>0||Math.abs(b[2]-v[2])<.15)&&Math.abs((b[1]+b[3]-v[1]-v[3])/2)<.11});if(!near&&(line.confidence<78||name.split(' ').length<3))continue;ranked.push({name,confidence:Math.round(line.confidence),score:line.confidence+(near?25:0)+Math.min(name.split(' ').length,5)*2})}
 ranked.sort((a,b)=>b.score-a.score);const best=ranked[0];if(!best)return {name:'',name_confidence:0,name_status:'تعذر التحقق من الاسم العربي؛ حدده أو أدخله يدويًا'};
 if(ranked.some(r=>r.score>=best.score-4&&nameKey(r.name)!==nameKey(best.name)&&!nameKey(best.name).includes(nameKey(r.name))&&!nameKey(r.name).includes(nameKey(best.name))))return {name:'',name_confidence:best.confidence,name_status:'قراءات عربية متعارضة؛ راجع الاسم من الجواز'};
 return {name:best.name,name_confidence:best.confidence,name_status:'اسم عربي مستخرج؛ راجعه قبل الاعتماد'};
}
export function passportText(text:string){
 const digit=(s:string)=>String([...s].reduce((n,c,i)=>n+Math.max(0,'0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'.indexOf(c))*[7,3,1][i%3],0)%10);
 for(const raw of text.split('\n')){const l=raw.toUpperCase().replace(/[^A-Z0-9<]/g,'');if(/^[A-Z0-9<]{9}[0-9][A-Z<]{3}[0-9]{6}/.test(l))return {passport:l.slice(0,9).replaceAll('<',''),mrz_valid:digit(l.slice(0,9))===l[9]}}
 const m=text.toUpperCase().match(/\b[A-Z]{1,3}[0-9]{5,9}\b|\b[0-9]{7,9}\b/);return {passport:m?.[0]||'',mrz_valid:false};
}
let serial:Promise<unknown>=Promise.resolve();
export function ocrTask<T>(task:()=>Promise<T>):Promise<T>{const next=serial.then(task,task);serial=next.catch(()=>{});return next}
let workerPromise:Promise<Worker>|undefined;
let progress:(n:number)=>void=()=>{};
async function worker(){return workerPromise??=createWorker(['ara','eng'],OEM.LSTM_ONLY,{workerPath:asset('worker.min.js'),corePath:asset('tesseract-core-lstm.wasm.js'),langPath:asset(''),gzip:false,cacheMethod:'write',logger:e=>{if(e.status==='recognizing text')progress(e.progress)}}).catch(e=>{workerPromise=undefined;throw e})}
function rotate(input:HTMLCanvasElement,angle:number){const swap=angle%180!==0,c=canvas(swap?input.height:input.width,swap?input.width:input.height),ctx=c.getContext('2d')!;ctx.translate(c.width/2,c.height/2);ctx.rotate(angle*Math.PI/180);ctx.drawImage(input,-input.width/2,-input.height/2);return c}
function region(input:HTMLCanvasElement,box:number[],upscale=false){const [x,y,w,h]=box,scale=upscale?Math.max(1,Math.min(3,2200/input.width)):1,c=canvas(input.width*w*scale,input.height*h*scale);c.getContext('2d')!.drawImage(input,input.width*x,input.height*y,input.width*w,input.height*h,0,0,c.width,c.height);return c}
function ocrLines(data:Awaited<ReturnType<Worker['recognize']>>['data'],box:number[],width:number,height:number):Line[]{const out:Line[]=[];for(const block of data.blocks||[])for(const p of block.paragraphs||[])for(const line of p.lines||[]){const words=line.words.filter(w=>/[\u0621-\u064A]/.test(w.text));if(!words.length)continue;const b=line.bbox,[x,y,w,h]=box;out.push({text:line.text,confidence:words.reduce((a,v)=>a+v.confidence,0)/words.length,box:[x+b.x0/width*w,y+b.y0/height*h,x+b.x1/width*w,y+b.y1/height*h]})}return out}
async function namePass(w:Worker,input:HTMLCanvasElement,focused=false){
 await w.reinitialize('ara',OEM.LSTM_ONLY);const lines:Line[]=[],regions=focused?[[0,0,1,1],[0,0,1,1]]:[[0,0,1,.74],[.45,.10,.54,.55]];
 for(let i=0;i<regions.length;i++){const b=regions[i],c=region(input,b,true);await w.setParameters({tessedit_pageseg_mode:focused?(i===0?PSM.SINGLE_LINE:PSM.SINGLE_BLOCK):(i===0?PSM.SPARSE_TEXT:PSM.SINGLE_BLOCK),tessedit_char_whitelist:'',preserve_interword_spaces:'1',user_defined_dpi:'300'});const {data}=await w.recognize(c,{}, {blocks:true,text:true});lines.push(...ocrLines(data,b,c.width,c.height))}
 return chooseName(lines,focused);
}
export function readName(c:HTMLCanvasElement){return ocrTask(async()=>namePass(await worker(),c,true))}
// OpenCV is a self-hosted asset; all pixel processing remains in the browser.
// eslint-disable-next-line @typescript-eslint/no-explicit-any
type CV=any;
let cvPromise:Promise<CV>|undefined;
async function cvRuntime():Promise<CV>{return cvPromise??=new Promise((resolve,reject)=>{const script=document.createElement('script');script.src=asset('opencv.js');const timer=setTimeout(()=>reject(Error('تعذر تحميل معالجة الصور')),60000);script.onerror=()=>{clearTimeout(timer);reject(Error('تعذر تحميل معالجة الصور'))};script.onload=async()=>{try{const cv=await (window as unknown as {cv:CV}).cv;if(cv.Mat){clearTimeout(timer);resolve(cv)}else{cv.onRuntimeInitialized=()=>{clearTimeout(timer);resolve(cv)}}}catch(e){clearTimeout(timer);reject(e)}};document.head.appendChild(script)}).catch(e=>{cvPromise=undefined;throw e})}
let cascadeReady=false;
export async function facePhoto(c:HTMLCanvasElement):Promise<HTMLCanvasElement|null>{
 let src:CV,gray:CV,faces:CV,classifier:CV;
 try{const cv=await cvRuntime();if(!cascadeReady){const r=await fetch(asset('haarcascade_frontalface_default.xml'));if(!r.ok)throw Error();cv.FS_createDataFile('/','face.xml',new Uint8Array(await r.arrayBuffer()),true,false,false);cascadeReady=true}
 src=cv.imread(c);gray=new cv.Mat();cv.cvtColor(src,gray,cv.COLOR_RGBA2GRAY);faces=new cv.RectVector();classifier=new cv.CascadeClassifier();if(!classifier.load('face.xml'))return null;classifier.detectMultiScale(gray,faces,1.1,5,0,new cv.Size(40,40));if(!faces.size())return null;let best=faces.get(0);for(let i=1;i<faces.size();i++){const f=faces.get(i);if(f.width*f.height>best.width*best.height)best=f}const x=Math.max(0,best.x-best.width*.35),y=Math.max(0,best.y-best.height*.45),right=Math.min(c.width,best.x+best.width*1.35),bottom=Math.min(c.height,best.y+best.height*1.65),out=canvas(right-x,bottom-y);out.getContext('2d')!.drawImage(c,x,y,right-x,bottom-y,0,0,out.width,out.height);return out;
 }catch{return null}finally{src?.delete();gray?.delete();faces?.delete();classifier?.delete()}
}
export function readPassport(input:HTMLCanvasElement,onProgress:(n:number)=>void){return ocrTask(async()=>{
 progress=n=>onProgress(10+Math.round(n*30));const w=await worker();let best:{canvas:HTMLCanvasElement;photo:HTMLCanvasElement|null;passport:string;mrz_valid:boolean;confidence:number;score:number}|undefined;
 for(const angle of [0,90,180,270]){
  const c=rotate(input,angle);await w.reinitialize('ara+eng',OEM.LSTM_ONLY);await w.setParameters({tessedit_pageseg_mode:PSM.AUTO,tessedit_char_whitelist:''});const full=(await w.recognize(c)).data;
  await w.reinitialize('eng',OEM.LSTM_ONLY);await w.setParameters({tessedit_pageseg_mode:PSM.SINGLE_BLOCK,tessedit_char_whitelist:'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789<'});const mrz=(await w.recognize(region(c,[0,.74,1,.26]))).data;
  const number=passportText(mrz.text+'\n'+full.text),photo=await facePhoto(c),score=Number(number.mrz_valid)*200+Number(!!number.passport)*50+Number(!!photo)*50+full.confidence;
  if(!best||score>best.score)best={canvas:c,photo,...number,confidence:Math.round(full.confidence),score};
  if(angle===0&&full.confidence>=55&&number.mrz_valid)break;
 }
 if(!best)throw Error('تعذر قراءة الجواز');onProgress(80);const name=await namePass(w,best.canvas);progress=()=>{};return {...best,...name};
})}
