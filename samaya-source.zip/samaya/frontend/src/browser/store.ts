import {defaults,type State} from './types';
const media=new Map<string,string>();
let database:Promise<IDBDatabase>|undefined;
const open=()=>database??=new Promise((resolve,reject)=>{
  const r=indexedDB.open('samaya-browser-v1',1);
  r.onupgradeneeded=()=>r.result.createObjectStore('state');
  r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(Error('تعذر فتح التخزين المحلي؛ تحقق من إعدادات المتصفح'));
});
export const imageUrl=(key?:string|null)=>key?media.get(key):undefined;
export async function readState():Promise<State>{
  const db=await open();return new Promise((resolve,reject)=>{const r=db.transaction('state').objectStore('state').get('current');r.onsuccess=()=>{const state:State=r.result||{version:1,records:[],settings:{...defaults},media:[]};state.media.forEach(m=>media.set(m.id,'data:image/png;base64,'+m.data));resolve(state)};r.onerror=()=>reject(r.error)});
}
export async function changeState<T>(fn:(state:State)=>T):Promise<T>{
  const db=await open();return new Promise((resolve,reject)=>{
    const tx=db.transaction('state','readwrite'),store=tx.objectStore('state'),r=store.get('current');let result:T,error:unknown;
    r.onsuccess=()=>{try{const state:State=r.result||{version:1,records:[],settings:{...defaults},media:[]};result=fn(state);store.put(state,'current');media.clear();state.media.forEach(m=>media.set(m.id,'data:image/png;base64,'+m.data))}catch(e){error=e;tx.abort()}};
    tx.oncomplete=()=>resolve(result);tx.onerror=tx.onabort=()=>reject(error||Error('تعذر حفظ البيانات؛ قد تكون مساحة الجهاز ممتلئة'));
  });
}
export function collectMedia(state:State){
  const used=new Set<string>();for(const r of [...state.records,state.settings])for(const k of ['photo','source','qr','logo']){const v=(r as unknown as Record<string,unknown>)[k];if(typeof v==='string')used.add(v)}state.media=state.media.filter(m=>used.has(m.id));
}
