import cssSource from '../../../shared/card.css?raw';
import template from '../../../shared/card.html?raw';
import {asset,type Pilgrim,type Settings} from './types';
import {imageUrl} from './store';
const escape=(s:unknown)=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]!));
let font:Promise<string>|undefined;
export function toBase64(bytes:Uint8Array){let out='';for(let i=0;i<bytes.length;i+=32768)out+=String.fromCharCode(...bytes.subarray(i,i+32768));return btoa(out)}
const fontUrl=()=>font??=fetch(asset('assets/Cairo.ttf')).then(r=>{if(!r.ok)throw Error('تعذر تحميل الخط العربي');return r.arrayBuffer()}).then(b=>'data:font/ttf;base64,'+toBase64(new Uint8Array(b)));
export async function renderCard(records:Pilgrim[],settings:Settings,mode='cr80',test=false){
  const img=(key:string|null|undefined,cls:string,style='')=>{const src=imageUrl(key);return src?`<img class="${cls}" style="${style}" src="${src}">`:`<div class="${cls} missing">غير مرفق</div>`};
  const css=cssSource.replace('FONT_URL',await fontUrl())+(mode==='a4'?'@page{size:A4;margin:10mm}.sheet{grid-template-columns:repeat(2,85.60mm);gap:1.5mm 5mm}':'@page{size:85.60mm 53.98mm;margin:0}.card{break-after:page}');
  const cards=records.map(r=>{const values:Record<string,string>={logo:img(settings.logo,'logo'),photo:img(r.photo,'portrait',`object-position:${r.photo_x??50}% ${r.photo_y??50}%;`),qr:img(r.qr||settings.qr,'qr')};for(const k of ['name','passport','hotel','supervisor','phone'] as const)values[k]=escape(r[k]);return template.replace(/\{\{(\w+)\}\}/g,(_,key)=>values[key]??'')}).join('');
  const ruler=test?'<div class="ruler">'+Array.from({length:11},(_,i)=>`<span style="left:${i*10}mm">${i*10}</span>`).join('')+'</div><p>المسطرة 100 ملم — اطبع بالحجم الفعلي 100٪ دون ملاءمة الصفحة.</p>':'';
  return `<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><style>${css}</style><body style="--primary:${settings.primary};--accent:${settings.accent};--secondary:${settings.secondary};--logo:${settings.logo_width}mm"><main class="sheet">${cards}</main>${ruler}</body></html>`;
}
