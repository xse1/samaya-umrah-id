import {getDocument,GlobalWorkerOptions} from 'pdfjs-dist';
import pdfWorker from 'pdfjs-dist/build/pdf.worker.min.mjs?url';
import {canvas,fromFile,MAX_FILE} from './images';
GlobalWorkerOptions.workerSrc=pdfWorker;
export async function* pages(file:File):AsyncGenerator<HTMLCanvasElement>{
 if(file.size>MAX_FILE)throw Error('الحد الأقصى للملف 20 ميجابايت');
 const signature=new TextDecoder().decode(await file.slice(0,5).arrayBuffer());
 if(signature!=='%PDF'){yield await fromFile(file);return}
 const task=getDocument({data:new Uint8Array(await file.arrayBuffer()),isEvalSupported:false,useSystemFonts:true});
 const doc=await task.promise;
 try{if(doc.numPages>10)throw Error('PDF يتجاوز 10 صفحات');for(let i=1;i<=doc.numPages;i++){const page=await doc.getPage(i),v=page.getViewport({scale:1}),scale=Math.min(2,2400/Math.max(v.width,v.height)),view=page.getViewport({scale}),c=canvas(view.width,view.height);await page.render({canvasContext:c.getContext('2d')!,viewport:view}).promise;yield c;page.cleanup()}}finally{await doc.destroy()}
}
