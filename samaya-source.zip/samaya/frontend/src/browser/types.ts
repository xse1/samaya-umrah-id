export type Pilgrim={id?:string;name:string;passport:string;photo?:string|null;source?:string|null;hotel:string;supervisor:string;phone:string;qr?:string|null;campaign:string;approved:boolean;reviewed:boolean;confidence:number;name_confidence?:number;name_status?:string;mrz_valid:boolean;ocr_status:string;photo_x:number;photo_y:number};
export type Settings={primary:string;accent:string;secondary:string;logo_width:number;logo?:string|null;qr?:string|null;hotel:string;supervisor:string;phone:string;campaign:string};
export type State={version:1;records:Pilgrim[];settings:Settings;media:{id:string;data:string}[]};
export const defaults:Settings={primary:'#329DD0',accent:'#F68B50',secondary:'#666666',logo_width:28,hotel:'',supervisor:'',phone:'',campaign:'الحملة الرئيسية'};
export const uuid=()=>crypto.randomUUID().replaceAll('-','');
export const asset=(path:string)=>new URL(import.meta.env.BASE_URL+(import.meta.env.VITE_BROWSER_MODE==='true'?path.split('/').pop():path),document.baseURI).href;
export const BROWSER_MODE=import.meta.env.VITE_BROWSER_MODE==='true';
