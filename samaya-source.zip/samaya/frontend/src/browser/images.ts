import jsQR from 'jsqr';
import {imageUrl,changeState} from './store';
import {uuid} from './types';
export const MAX_FILE=20*1024*1024;
export async function decode(src:string):Promise<HTMLImageElement>{return new Promise((resolve,reject)=>{const i=new Image();i.onload=()=>resolve(i);i.onerror=()=>reject(Error('الصورة غير صالحة'));i.src=src})}
export function canvas(width:number,height:number){const c=document.createElement('canvas');c.width=Math.round(width);c.height=Math.round(height);return c}
export async function imageCanvas(src:string,max=3000){const image=await decode(src);if(image.width*image.height>30_000_000)throw Error('أبعاد الصورة كبيرة جدًا');const scale=Math.min(1,max/Math.max(image.width,image.height)),c=canvas(image.width*scale,image.height*scale),ctx=c.getContext('2d')!;ctx.fillStyle='white';ctx.fillRect(0,0,c.width,c.height);ctx.drawImage(image,0,0,c.width,c.height);return c}
export async function fromFile(file:File,logo=false){
 if(file.size>MAX_FILE)throw Error('الحد الأقصى للملف 20 ميجابايت');
 const head=new Uint8Array(await file.slice(0,32).arrayBuffer());const ascii=new TextDecoder().decode(head);
 let blob:Blob=file;
 if(file.name.toLowerCase().endsWith('.svg')){
   if(!logo)throw Error('SVG مسموح للشعار فقط');
   const text=await file.text(),doc=new DOMParser().parseFromString(text,'image/svg+xml');
   if(doc.querySelector('parsererror')||doc.documentElement.localName!=='svg')throw Error('ملف SVG غير صالح');
   for(const node of [doc.documentElement,...Array.from(doc.querySelectorAll('*'))]){
     if(['script','foreignObject','image','use','style','a'].includes(node.localName))throw Error('SVG يتضمن عناصر غير مسموحة؛ استخدم PNG');
     for(const a of Array.from(node.attributes))if(a.name.toLowerCase().startsWith('on')||/url\(|https?:|file:|javascript:|data:/i.test(a.value))throw Error('SVG يتضمن مرجعًا غير مسموح');
   }
   blob=new Blob([new XMLSerializer().serializeToString(doc)],{type:'image/svg+xml'});
 }else if(!(head[0]===137&&head[1]===80&&head[2]===78&&head[3]===71)&&!(head[0]===255&&head[1]===216)&&!(ascii.startsWith('RIFF')&&ascii.slice(8,12)==='WEBP'))throw Error('ارفع صورة JPG أو PNG أو WEBP سليمة');
 const url=URL.createObjectURL(blob);try{return await imageCanvas(url)}finally{URL.revokeObjectURL(url)}
}
export async function saveCanvas(c:HTMLCanvasElement){const id=uuid(),data=c.toDataURL('image/png').split(',')[1];await changeState(s=>s.media.push({id,data}));return id}
export async function cropImage(key:string,x:number,y:number,width:number,height:number){
 if(![x,y,width,height].every(Number.isFinite)||x<0||y<0||width<=0||height<=0||x+width>1.001||y+height>1.001)throw Error('حدود القص خارج الصورة');
 const src=imageUrl(key);if(!src)throw Error('الصورة غير موجودة');const i=await decode(src),c=canvas(i.width*width,i.height*height);
 if(c.width<10||c.height<10)throw Error('منطقة القص صغيرة جدًا');c.getContext('2d')!.drawImage(i,i.width*x,i.height*y,i.width*width,i.height*height,0,0,c.width,c.height);return saveCanvas(c)
}
export function qrReadable(c:HTMLCanvasElement){const ctx=c.getContext('2d')!,data=ctx.getImageData(0,0,c.width,c.height);return !!jsQR(data.data,c.width,c.height)}
export function palette(c:HTMLCanvasElement){const small=canvas(80,80);small.getContext('2d')!.drawImage(c,0,0,80,80);const pixels=small.getContext('2d')!.getImageData(0,0,80,80).data,buckets=new Map<string,number>();for(let i=0;i<pixels.length;i+=4){const rgb=[pixels[i],pixels[i+1],pixels[i+2]].map(v=>Math.min(255,Math.round(v/32)*32));if(Math.max(...rgb)-Math.min(...rgb)<40)continue;const key='#'+rgb.map(v=>v.toString(16).padStart(2,'0')).join('');buckets.set(key,(buckets.get(key)||0)+1)}return [...buckets].sort((a,b)=>b[1]-a[1]).slice(0,4).map(v=>v[0])}
