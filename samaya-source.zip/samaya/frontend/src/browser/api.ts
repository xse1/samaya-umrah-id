import {asset,uuid,defaults,type Pilgrim,type Settings,type State} from './types';
import {readState,changeState,imageUrl,collectMedia} from './store';
import {fromFile,imageCanvas,saveCanvas,cropImage,qrReadable,palette} from './images';
import {renderCard} from './card';
import {pack,unpack} from './backup';
import {readName,readPassport,facePhoto} from './recognition';
import {pages} from './documents';
type Job={id:string;filename:string;status:string;progress:number;warning?:string;record?:Pilgrim};
const jobs:Job[]=[];
let queue:Promise<void>=Promise.resolve();
const result=(body:unknown,status=200,type='application/json')=>new Response(typeof body==='string'?body:JSON.stringify(body),{status,headers:{'Content-Type':type}});
const empty=(s:Settings):Pilgrim=>({name:'',passport:'',hotel:s.hotel,supervisor:s.supervisor,phone:s.phone,qr:s.qr,campaign:s.campaign,approved:false,reviewed:false,confidence:0,mrz_valid:false,ocr_status:'يدوي',photo_x:50,photo_y:50});
function settingsValid(s:Settings){for(const color of [s.primary,s.accent,s.secondary])if(!/^#[0-9a-f]{6}$/i.test(color))throw Error('صيغة اللون غير صحيحة');if(!s.campaign?.trim()||s.campaign.length>80||!Number.isFinite(s.logo_width)||s.logo_width<10||s.logo_width>42)throw Error('تحقق من اسم الحملة وحجم الشعار');for(const k of ['hotel','supervisor','phone'] as const)if(typeof s[k]!=='string'||s[k].length>(k==='phone'?25:70))throw Error('بيانات الحملة أطول من المساحة المسموحة')}
function recordValid(p:Pilgrim,s:State){
 for(const [key,max] of [['name',90],['passport',20],['hotel',70],['supervisor',70],['phone',25],['campaign',80]] as const)if(typeof p[key]!=='string'||p[key].length>max)throw Error('تحقق من الحقول وأطوالها');
 for(const k of ['photo_x','photo_y'] as const)if(!Number.isFinite(p[k])||p[k]<0||p[k]>100)throw Error('موضع الصورة غير صالح');
 for(const k of ['photo','source','qr'] as const)if(p[k]&&!s.media.some(m=>m.id===p[k]))throw Error('إحدى صور السجل غير موجودة');
 if(p.approved){if(!p.reviewed)throw Error('أكد مراجعة البيانات يدويًا');if(!p.name||!p.passport||!p.photo||!p.hotel||!p.supervisor||!p.phone)throw Error('أكمل الاسم والجواز والصورة والفندق وبيانات المشرف');if(!/^[A-Z0-9]{5,20}$/.test(p.passport)||!/[\u0621-\u064A]/.test(p.name))throw Error('راجع الاسم العربي ورقم الجواز');if(!p.qr&&!s.settings.qr)throw Error('ارفع رمز الفندق قبل الاعتماد')}
 if(p.passport&&s.records.some(r=>r.id!==p.id&&r.passport===p.passport))throw Error('رقم الجواز موجود مسبقًا؛ صححه أو عدّل السجل الموجود');
}
async function saveRecord(input:Partial<Pilgrim>){return changeState(s=>{const p={...empty(s.settings),...input,id:input.id||uuid()};p.name=p.name.trim();p.passport=p.passport.trim().toUpperCase();recordValid(p,s);const i=s.records.findIndex(r=>r.id===p.id);if(i<0)s.records.unshift(p);else s.records[i]=p;return p})}
async function processFile(job:Job,file:File){
 try{job.status='معالجة';job.progress=5;let best:Awaited<ReturnType<typeof readPassport>>|undefined,first:HTMLCanvasElement|undefined,warning='';
 for await(const image of pages(file)){
  first??=image;
  try{const r=await readPassport(image,n=>job.progress=n);if(!best||r.score>best.score)best=r}catch{warning='تعذر OCR؛ يمكنك تحديد الصورة والاسم يدويًا'}
 }
 const s=(await readState()).settings;if(!best&&!first)throw Error('لا توجد صفحة قابلة للقراءة');
 const source=await saveCanvas(best?.canvas||first!),portrait=best?.photo||await facePhoto(first!),photo=portrait?await saveCanvas(portrait):null;
 const draft:Partial<Pilgrim>={...empty(s),name:best?.name||'',passport:best?.passport||'',name_confidence:best?.name_confidence||0,name_status:best?.name_status,confidence:best?.confidence||0,mrz_valid:best?.mrz_valid||false,source,photo,ocr_status:best?'مراجعة مطلوبة':'استخراج غير مكتمل'};
 try{job.record=await saveRecord(draft)}catch(e){if(!(e instanceof Error)||!e.message.includes('موجود مسبقًا'))throw e;const number=draft.passport;draft.passport='';job.record=await saveRecord(draft);warning=`تعارض الجواز ${number}؛ حُفظت مسودة دون رقم للمراجعة`}
 job.warning=warning||(!draft.name?'تعذرت قراءة الاسم بثقة؛ حدد موضعه أو أدخله يدويًا':'راجع الاسم والجواز والصورة قبل الاعتماد');job.status='مكتمل';job.progress=100;
 }catch(e){job.status='فشل';job.progress=100;job.warning=e instanceof Error?e.message:'تعذرت معالجة الملف'}
}
let boot:Promise<void>|undefined;
async function initialize(){return boot??=(async()=>{const state=await readState();if(!state.settings.logo){try{const r=await fetch(asset('samaya-logo.png'));if(r.ok){const c=await fromFile(new File([await r.blob()],'samaya-logo.png',{type:'image/png'}),true);const id=await saveCanvas(c);await changeState(s=>{if(!s.settings.logo)s.settings.logo=id})}}catch{}}})().catch(e=>{boot=undefined;throw e})}
export async function browserApi(path:string,options:RequestInit={}):Promise<Response>{
 try{
 await initialize();const method=options.method||'GET',form=options.body instanceof FormData?options.body:null,body=form?{}:options.body?JSON.parse(String(options.body)):{};
 if(path==='/session')return result({token:'browser-local'});
 if(path==='/health')return result({ok:true,ocr:{ready:typeof Worker!=='undefined'&&typeof WebAssembly!=='undefined',languages:['ara','eng']},font:true});
 if(path==='/settings'){
  if(method==='GET')return result((await readState()).settings);
  const s={...defaults,...body} as Settings;settingsValid(s);const old=await readState();for(const key of [s.logo,s.qr])if(key&&!old.media.some(m=>m.id===key))throw Error('الصورة غير موجودة');await changeState(state=>{state.settings=s});return result(s);
 }
 if(path==='/pilgrims')return result(method==='GET'?(await readState()).records:await saveRecord(body));
 const id=path.split('/')[2];
 if(path.startsWith('/pilgrims/')&&method==='DELETE'){
  const sourceOnly=path.endsWith('/source');await changeState(s=>{if(sourceOnly){const p=s.records.find(r=>r.id===id);if(!p)throw Error('السجل غير موجود');p.source=null}else s.records=s.records.filter(r=>r.id!==id);collectMedia(s)});
  for(let i=jobs.length-1;i>=0;i--)if(jobs[i].record?.id===id){if(sourceOnly)jobs[i].record!.source=null;else jobs.splice(i,1)}return result({ok:true});
 }
 if(path==='/campaign/delete'){
  if(jobs.some(j=>j.progress<100))throw Error('انتظر انتهاء مهام الاستخراج قبل حذف الحملة');if(body.confirmation!==body.campaign)throw Error('اكتب اسم الحملة للتأكيد');await changeState(s=>{s.records=s.records.filter(r=>r.campaign!==body.campaign);collectMedia(s)});for(let i=jobs.length-1;i>=0;i--)if(jobs[i].record?.campaign===body.campaign)jobs.splice(i,1);return result({ok:true});
 }
 if(path==='/images'){
  const file=form?.get('file');if(!(file instanceof File))throw Error('اختر صورة');const kind=String(form?.get('kind')||'photo'),c=await fromFile(file,kind==='logo'),key=await saveCanvas(c);return result({id:key,colors:palette(c),qr_readable:kind==='qr'?qrReadable(c):false});
 }
 if(path==='/crop')return result({id:await cropImage(body.image,body.x,body.y,body.width,body.height)});
 if(path==='/arabic-name'){const src=imageUrl(body.image);if(!src)throw Error('الصورة غير موجودة');return result(await readName(await imageCanvas(src)))}
 if(path==='/passports'){
  const files=form?.getAll('files').filter((f):f is File=>f instanceof File)||[];if(!files.length||files.length>30)throw Error('ارفع من 1 إلى 30 ملفًا في الدفعة');if(jobs.filter(j=>j.progress<100).length+files.length>60)throw Error('انتظر انتهاء الدفعة الحالية');if(files.some(f=>f.size>20*1024*1024))throw Error('الحد الأقصى للملف 20 ميجابايت');const ids:string[]=[];
  for(const file of files){const job:Job={id:uuid(),filename:file.name,status:'انتظار',progress:0};jobs.push(job);ids.push(job.id);queue=queue.then(()=>processFile(job,file))}return result({ids});
 }
 if(path==='/jobs')return result(jobs.slice(-100));
 if(path.startsWith('/reextract/')){const s=await readState(),p=s.records.find(r=>r.id===id),src=imageUrl(p?.source);if(!src)throw Error('صورة الجواز الأصلية غير موجودة');const blob=await(await fetch(src)).blob(),file=new File([blob],'إعادة استخراج.png',{type:'image/png'}),job:Job={id:uuid(),filename:file.name,status:'انتظار',progress:0};jobs.push(job);queue=queue.then(()=>processFile(job,file));return result({id:job.id})}
 if(path==='/preview'||path==='/print-layout'){
  const s=await readState();if(!['cr80','a4'].includes(body.mode||'cr80'))throw Error('مقاس طباعة غير مدعوم');let records:Pilgrim[]=body.records||[];
  if(path==='/print-layout'){const ids=[...new Set<string>(body.ids||[])];if(ids.length>200)throw Error('اختر حتى 200 بطاقة للملف');records=s.records.filter(p=>ids.includes(p.id!));if(records.length!==ids.length||records.some(p=>!p.approved))throw Error('اختر بطاقات محفوظة ومعتمدة فقط')}
  if(!records.length&&!body.test)throw Error('اختر بطاقة واحدة على الأقل');return result(await renderCard(records,s.settings,body.mode||'cr80',!!body.test),200,'text/html');
 }
 if(path==='/export.csv'){
  const s=await readState(),escape=(v:unknown)=>{let text=String(v??'');if(/^[=+\-@\t\r]/.test(text))text="'"+text;return '"'+text.replaceAll('"','""')+'"'};
  const rows=[['الاسم','رقم الجواز','الفندق','المشرف','الهاتف','الحملة','الحالة'],...s.records.map(p=>[p.name,p.passport,p.hotel,p.supervisor,p.phone,p.campaign,p.approved?'معتمدة':'تحتاج مراجعة'])];return result('\uFEFF'+rows.map(r=>r.map(escape).join(',')).join('\r\n'),200,'text/csv');
 }
 if(path==='/backup')return new Response(await pack(await readState(),String(body.password||'')),{headers:{'Content-Type':'application/octet-stream'}});
 if(path==='/restore'){
  if(jobs.some(j=>j.progress<100))throw Error('انتظر انتهاء معالجة الجوازات قبل الاستعادة');if(form?.get('confirmation')!=='استعادة')throw Error('اكتب استعادة للتأكيد');const file=form.get('file');if(!(file instanceof File))throw Error('اختر نسخة احتياطية');const state=await unpack(file,String(form.get('password')||''));
  const mediaIds=new Set<string>(),recordIds=new Set<string>();settingsValid(state.settings);state.records=state.records.map(p=>({...empty(state.settings),...p,passport:String(p.passport??'').trim().toUpperCase(),name:String(p.name??'').trim()}));
  for(const m of state.media){if(!/^[a-f0-9]{32}$/.test(m.id)||mediaIds.has(m.id)||typeof m.data!=='string'||m.data.length>30*1024*1024||!m.data.startsWith('iVBORw0KGgo'))throw Error('صورة غير صالحة في النسخة');mediaIds.add(m.id);await imageCanvas('data:image/png;base64,'+m.data)}
  for(const p of state.records){if(!p.id||!/^[a-f0-9]{32}$/.test(p.id)||recordIds.has(p.id))throw Error('معرّف سجل غير صالح');recordIds.add(p.id);recordValid(p,state)}for(const key of [state.settings.logo,state.settings.qr])if(key&&!mediaIds.has(key))throw Error('صورة إعدادات غير موجودة');
  await changeState(s=>{s.records=state.records;s.settings=state.settings;s.media=state.media});jobs.splice(0);return result({ok:true});
 }
 throw Error('العملية غير مدعومة');
 }catch(e){return result({detail:e instanceof Error?e.message:'تعذر إتمام العملية محليًا'},400)}
}
