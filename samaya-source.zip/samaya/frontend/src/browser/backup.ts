import {scrypt} from 'scrypt-js';
import type {State} from './types';
const encode=new TextEncoder(),decode=new TextDecoder();
const key=async(password:string,salt:Uint8Array)=>crypto.subtle.importKey('raw',await scrypt(encode.encode(password),salt,16384,8,1,32) as BufferSource,'AES-GCM',false,['encrypt','decrypt']);
export async function pack(state:State,password:string){const plain=encode.encode(JSON.stringify(state));if(!password)return new Blob([plain],{type:'application/octet-stream'});const salt=crypto.getRandomValues(new Uint8Array(16)),nonce=crypto.getRandomValues(new Uint8Array(12));const encrypted=await crypto.subtle.encrypt({name:'AES-GCM',iv:nonce,additionalData:encode.encode('SAMAYA1')},await key(password,salt),plain);return new Blob([encode.encode('SAMAYA1'),salt,nonce,encrypted],{type:'application/octet-stream'})}
export async function unpack(file:File,password:string):Promise<State>{
 if(file.size>250*1024*1024)throw Error('النسخة أكبر من 250 ميجابايت');
 try{let b=new Uint8Array(await file.arrayBuffer());if(decode.decode(b.subarray(0,7))==='SAMAYA1'){const plain=await crypto.subtle.decrypt({name:'AES-GCM',iv:b.subarray(23,35),additionalData:encode.encode('SAMAYA1')},await key(password,b.subarray(7,23)),b.subarray(35) as BufferSource);b=new Uint8Array(plain)}const value=JSON.parse(decode.decode(b));if(value.version!==1||!Array.isArray(value.records)||!Array.isArray(value.media)||!value.settings)throw Error();return value}catch{throw Error('النسخة غير صالحة أو كلمة المرور غير صحيحة؛ لم تُستبدل البيانات')}
}
