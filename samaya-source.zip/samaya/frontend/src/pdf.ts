import {jsPDF} from 'jspdf';
import {toPng} from 'html-to-image';

// Use the server-validated HTML template; every font and image is embedded locally.
export async function makePdf(html:string,mode:'a4'|'cr80',test=false):Promise<Blob>{
  const iframe=document.createElement('iframe');
  iframe.setAttribute('aria-hidden','true');
  iframe.style.cssText='position:fixed;left:-20000px;top:0;width:210mm;height:297mm;border:0;pointer-events:none';
  document.body.appendChild(iframe);
  try{
    await new Promise<void>((resolve,reject)=>{
      iframe.onload=()=>resolve();iframe.onerror=()=>reject(Error('تعذر تحميل قالب الطباعة'));
      iframe.srcdoc=html;
    });
    const doc=iframe.contentDocument!;
    await doc.fonts.ready;
    await Promise.all(Array.from(doc.images).map(image=>image.decode()));
    const nodes=Array.from(doc.querySelectorAll<HTMLElement>('.name,.details'));
    if(nodes.some(n=>n.scrollHeight>n.clientHeight+1||n.scrollWidth>n.clientWidth+1))throw Error('النص يتجاوز مساحة البطاقة؛ راجعه قبل الطباعة');
    const pdf=new jsPDF({unit:'mm',format:mode==='a4'?[210,297]:[85.6,53.98],orientation:mode==='a4'?'portrait':'landscape',compress:true,precision:12});
    const fontEmbedCSS=doc.querySelector('style')!.textContent!.match(/@font-face\{[^}]+\}/)?.[0]||'';
    const capture=(element:HTMLElement)=>toPng(element,{pixelRatio:300/96,backgroundColor:'#FFFFFF',fontEmbedCSS,cacheBust:false});
    if(test){
      doc.body.style.width='190mm';doc.body.style.height='277mm';
      pdf.addImage(await capture(doc.body),'PNG',10,10,190,277,undefined,'FAST');
    }else{
      const cards=Array.from(doc.querySelectorAll<HTMLElement>('.card'));
      if(!cards.length)throw Error('لا توجد بطاقات معتمدة للطباعة');
      for(let index=0;index<cards.length;index++){
        if(index>0&&(mode==='cr80'||index%10===0))pdf.addPage();
        const col=1-index%2,row=Math.floor(index%10/2);
        const x=mode==='cr80'?0:16.9+col*90.6;
        const y=mode==='cr80'?0:10+row*55.48;
        pdf.addImage(await capture(cards[index]),'PNG',x,y,85.6,53.98,undefined,'FAST');
        // Let the interface paint during large exports.
        await new Promise<void>(resolve=>requestAnimationFrame(()=>resolve()));
      }
    }
    return pdf.output('blob');
  }finally{iframe.remove()}
}
